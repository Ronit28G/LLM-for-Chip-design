module propagate_generate(
    input a,
    input b,
    output g,
    output p
);
    and(g, a, b);
    xor(p, a, b);
endmodule

module carry_lookahead_adder(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);
    wire [7:0] g;
    wire [7:0] p;
    wire [7:0] c;
    wire cin;
    
    wire c1_t1, c1_t2;
    wire c2_t1, c2_t2, c2_t3;
    wire c3_t1, c3_t2, c3_t3, c3_t4;
    wire c4_t1, c4_t2, c4_t3, c4_t4, c4_t5;
    wire c5_t1, c5_t2, c5_t3, c5_t4, c5_t5, c5_t6;
    wire c6_t1, c6_t2, c6_t3, c6_t4, c6_t5, c6_t6, c6_t7;
    wire c7_t1, c7_t2, c7_t3, c7_t4, c7_t5, c7_t6, c7_t7, c7_t8;
    wire cout_t1, cout_t2, cout_t3, cout_t4, cout_t5, cout_t6, cout_t7, cout_t8, cout_t9;
    
    assign cin = 1'b0;
    
    propagate_generate pg0(.a(a[0]), .b(b[0]), .g(g[0]), .p(p[0]));
    propagate_generate pg1(.a(a[1]), .b(b[1]), .g(g[1]), .p(p[1]));
    propagate_generate pg2(.a(a[2]), .b(b[2]), .g(g[2]), .p(p[2]));
    propagate_generate pg3(.a(a[3]), .b(b[3]), .g(g[3]), .p(p[3]));
    propagate_generate pg4(.a(a[4]), .b(b[4]), .g(g[4]), .p(p[4]));
    propagate_generate pg5(.a(a[5]), .b(b[5]), .g(g[5]), .p(p[5]));
    propagate_generate pg6(.a(a[6]), .b(b[6]), .g(g[6]), .p(p[6]));
    propagate_generate pg7(.a(a[7]), .b(b[7]), .g(g[7]), .p(p[7]));
    
    buf(c[0], cin);
    
    and(c1_t1, p[0], cin);
    buf(c1_t2, g[0]);
    or(c[1], c1_t1, c1_t2);
    
    and(c2_t1, p[1], p[0], cin);
    and(c2_t2, p[1], g[0]);
    buf(c2_t3, g[1]);
    or(c[2], c2_t1, c2_t2, c2_t3);
    
    and(c3_t1, p[2], p[1], p[0], cin);
    and(c3_t2, p[2], p[1], g[0]);
    and(c3_t3, p[2], g[1]);
    buf(c3_t4, g[2]);
    or(c[3], c3_t1, c3_t2, c3_t3, c3_t4);
    
    and(c4_t1, p[3], p[2], p[1], p[0], cin);
    and(c4_t2, p[3], p[2], p[1], g[0]);
    and(c4_t3, p[3], p[2], g[1]);
    and(c4_t4, p[3], g[2]);
    buf(c4_t5, g[3]);
    or(c[4], c4_t1, c4_t2, c4_t3, c4_t4, c4_t5);
    
    and(c5_t1, p[4], p[3], p[2], p[1], p[0], cin);
    and(c5_t2, p[4], p[3], p[2], p[1], g[0]);
    and(c5_t3, p[4], p[3], p[2], g[1]);
    and(c5_t4, p[4], p[3], g[2]);
    and(c5_t5, p[4], g[3]);
    buf(c5_t6, g[4]);
    or(c[5], c5_t1, c5_t2, c5_t3, c5_t4, c5_t5, c5_t6);
    
    and(c6_t1, p[5], p[4], p[3], p[2], p[1], p[0], cin);
    and(c6_t2, p[5], p[4], p[3], p[2], p[1], g[0]);
    and(c6_t3, p[5], p[4], p[3], p[2], g[1]);
    and(c6_t4, p[5], p[4], p[3], g[2]);
    and(c6_t5, p[5], p[4], g[3]);
    and(c6_t6, p[5], g[4]);
    buf(c6_t7, g[5]);
    or(c[6], c6_t1, c6_t2, c6_t3, c6_t4, c6_t5, c6_t6, c6_t7);
    
    and(c7_t1, p[6], p[5], p[4], p[3], p[2], p[1], p[0], cin);
    and(c7_t2, p[6], p[5], p[4], p[3], p[2], p[1], g[0]);
    and(c7_t3, p[6], p[5], p[4], p[3], p[2], g[1]);
    and(c7_t4, p[6], p[5], p[4], p[3], g[2]);
    and(c7_t5, p[6], p[5], p[4], g[3]);
    and(c7_t6, p[6], p[5], g[4]);
    and(c7_t7, p[6], g[5]);
    buf(c7_t8, g[6]);
    or(c[7], c7_t1, c7_t2, c7_t3, c7_t4, c7_t5, c7_t6, c7_t7, c7_t8);
    
    and(cout_t1, p[7], p[6], p[5], p[4], p[3], p[2], p[1], p[0], cin);
    and(cout_t2, p[7], p[6], p[5], p[4], p[3], p[2], p[1], g[0]);
    and(cout_t3, p[7], p[6], p[5], p[4], p[3], p[2], g[1]);
    and(cout_t4, p[7], p[6], p[5], p[4], p[3], g[2]);
    and(cout_t5, p[7], p[6], p[5], p[4], g[3]);
    and(cout_t6, p[7], p[6], p[5], g[4]);
    and(cout_t7, p[7], p[6], g[5]);
    and(cout_t8, p[7], g[6]);
    buf(cout_t9, g[7]);
    or(cout, cout_t1, cout_t2, cout_t3, cout_t4, cout_t5, cout_t6, cout_t7, cout_t8, cout_t9);
    
    xor(sum[0], p[0], c[0]);
    xor(sum[1], p[1], c[1]);
    xor(sum[2], p[2], c[2]);
    xor(sum[3], p[3], c[3]);
    xor(sum[4], p[4], c[4]);
    xor(sum[5], p[5], c[5]);
    xor(sum[6], p[6], c[6]);
    xor(sum[7], p[7], c[7]);
endmodule