module tb_carry_lookahead_adder;
    reg [7:0] a;
    reg [7:0] b;
    wire [7:0] sum;
    wire cout;
    
    wire [7:0] g;
    wire [7:0] p;
    wire [7:0] c;
    
    integer i;
    integer total_tests;
    integer total_failures;
    reg [8:0] expected;
    
    carry_lookahead_adder uut (
        .a(a),
        .b(b),
        .sum(sum),
        .cout(cout)
    );
    
    assign g = uut.g;
    assign p = uut.p;
    assign c = uut.c;
    
    initial begin
        total_tests = 0;
        total_failures = 0;
        
        for (i = 0; i < 65536; i = i + 1) begin
            a = i[15:8];
            b = i[7:0];
            expected = a + b;
            #1;
            
            total_tests = total_tests + 1;
            
            if ({cout, sum} !== expected) begin
                $display("FAIL: a=%h b=%h sum=%h cout=%b expected=%h | g=%b p=%b c=%b",
                         a, b, sum, cout, expected, g, p, c);
                total_failures = total_failures + 1;
            end
        end
        
        $display("\n=== Test Summary ===");
        $display("Total tests run: %0d", total_tests);
        $display("Total failures: %0d", total_failures);
        if (total_failures == 0) begin
            $display("All tests PASSED!");
        end else begin
            $display("Some tests FAILED!");
        end
        
        $finish;
    end
endmodule