module tb_carry_lookahead_adder;
    reg [7:0] a, b;
    wire [7:0] sum;
    wire cout;
    wire [7:0] g;
    wire [7:0] p;
    wire [7:0] c;
    integer i;
    integer total_tests = 0;
    integer failures = 0;

    carry_lookahead_adder UUT (
        .a(a),
        .b(b),
        .sum(sum),
        .cout(cout)
    );

    initial begin
        a = 0;
        b = 0;

        for (i = 0; i < 65536; i = i + 1) begin
            a = i[15:8];
            b = i[7:0];
            #1; // Wait for a moment to ensure everything settles

            // Compute expected results
            {expected_cout, expected_sum} = a + b;

            // Check the results
            if (sum !== expected_sum || cout !== expected_cout) begin
                $display("Test FAILED for a=%b, b=%b: sum=%b, cout=%b, expected_sum=%b, expected_cout=%b", 
                         a, b, sum, cout, expected_sum, expected_cout);
                failures = failures + 1;
            end
            total_tests = total_tests + 1;
        end

        // Final Summary
        $display("Total tests run: %0d", total_tests);
        $display("Total failures: %0d", failures);

        $finish;
    end
endmodule