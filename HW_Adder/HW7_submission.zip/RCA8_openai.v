module RCA8(
    input [7:0] A,
    input [7:0] B,
    output [7:0] SUM,
    output COUT
);
    wire c1, c2, c3, c4, c5, c6, c7;

    FA fa0(.A(A[0]), .B(B[0]), .CIN(1'b0), .SUM(SUM[0]), .COUT(c1));
    FA fa1(.A(A[1]), .B(B[1]), .CIN(c1), .SUM(SUM[1]), .COUT(c2));
    FA fa2(.A(A[2]), .B(B[2]), .CIN(c2), .SUM(SUM[2]), .COUT(c3));
    FA fa3(.A(A[3]), .B(B[3]), .CIN(c3), .SUM(SUM[3]), .COUT(c4));
    FA fa4(.A(A[4]), .B(B[4]), .CIN(c4), .SUM(SUM[4]), .COUT(c5));
    FA fa5(.A(A[5]), .B(B[5]), .CIN(c5), .SUM(SUM[5]), .COUT(c6));
    FA fa6(.A(A[6]), .B(B[6]), .CIN(c6), .SUM(SUM[6]), .COUT(c7));
    FA fa7(.A(A[7]), .B(B[7]), .CIN(c7), .SUM(SUM[7]), .COUT(COUT));

endmodule

module FA(
    input A,
    input B,
    input CIN,
    output SUM,
    output COUT
);
    wire axorb, aandb, aorbandcin;

    xor (axorb, A, B);
    xor (SUM, axorb, CIN);
    and (aandb, A, B);
    and (aorbandcin, axorb, CIN);
    or  (COUT, aandb, aorbandcin);

endmodule