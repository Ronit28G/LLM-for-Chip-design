module tb_eight_bit_ripple_carry_adder;
    reg [7:0] a;
    reg [7:0] b;
    wire [7:0] sum;
    wire cout;
    
    integer i;
    integer total_tests;
    integer total_failures;
    reg [8:0] expected;
    
    eight_bit_ripple_carry_adder uut (
        .a(a),
        .b(b),
        .sum(sum),
        .cout(cout)
    );
    
    initial begin
        total_tests = 0;
        total_failures = 0;
        
        for (i = 0; i < 65536; i = i + 1) begin
            a = i[15:8];
            b = i[7:0];
            expected = a + b;
            #1;
            
            total_tests = total_tests + 1;
            
            if ({cout, sum} !== expected) begin
                $display("FAIL: a=%d, b=%d, expected={%b,%b}, got={%b,%b}, carry internal={%b,%b,%b,%b,%b,%b,%b}",
                         a, b, expected[8], expected[7:0], cout, sum,
                         uut.carry[0], uut.carry[1], uut.carry[2], uut.carry[3],
                         uut.carry[4], uut.carry[5], uut.carry[6]);
                total_failures = total_failures + 1;
            end
        end
        
        $display("======================================");
        $display("Test Summary:");
        $display("Total tests run: %d", total_tests);
        $display("Total failures: %d", total_failures);
        $display("======================================");
        
        $finish;
    end
endmodule