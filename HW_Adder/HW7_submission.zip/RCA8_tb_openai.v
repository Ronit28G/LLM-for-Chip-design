module tb_eight_bit_ripple_carry_adder;
    reg [7:0] a;
    reg [7:0] b;
    wire [7:0] sum;
    wire cout;
    wire [6:0] c;
    integer i;
    integer failures;
    
    eight_bit_ripple_carry_adder UUT (
        .a(a),
        .b(b),
        .sum(sum),
        .cout(cout)
    );
    
    assign c = {UUT.fa6.cout, UUT.fa5.cout, UUT.fa4.cout, UUT.fa3.cout, UUT.fa2.cout, UUT.fa1.cout, UUT.fa0.cout};
    
    initial begin
        failures = 0;
        for (i = 0; i < 65536; i = i + 1) begin
            a = i[15:8];
            b = i[7:0];
            #5;
            if ({cout, sum} !== a + b) begin
                $display("Test failed for a = %h, b = %h. Expected %h, got %h (%b)", a, b, a + b, {cout, sum}, c);
                failures = failures + 1;
            end
        end
        $display("Total tests run: 65536, Total failures: %d", failures);
        $finish;
    end
endmodule