module tb_adder8;
  reg [7:0] a, b;
  wire [7:0] sum;
  wire cout;
  
  integer i;
  integer total_tests;
  integer total_failures;
  reg [8:0] expected;

  adder8 uut (.a(a), .b(b), .sum(sum), .cout(cout));

  initial begin
    total_tests = 0;
    total_failures = 0;

    for (i = 0; i < 65536; i = i + 1) begin
      a = i[15:8];
      b = i[7:0];
      expected = a + b;
      #1;
      total_tests = total_tests + 1;
      if ({cout, sum} !== expected) begin
        $display("FAIL: a=%d b=%d expected=%b got=%b",
                 a, b, expected, {cout, sum});
        total_failures = total_failures + 1;
      end
    end

    $display("=== Mode C Best Adder Verification ===");
    $display("Total tests run: %0d", total_tests);
    $display("Total failures: %0d", total_failures);
    if (total_failures == 0)
      $display("ALL TESTS PASSED!");
    else
      $display("SOME TESTS FAILED!");
    $finish;
  end
endmodule