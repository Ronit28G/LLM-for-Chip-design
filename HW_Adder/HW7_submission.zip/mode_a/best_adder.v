// Full Adder
module FA(output sum, cout, input a, b, cin);
  wire w0, w1, w2;
  
  xor  (w0, a, b);
  xor  (sum, w0, cin);
  
  and  (w1, w0, cin);
  and  (w2, a, b);
  or  (cout, w1, w2);
endmodule

// Carry Lookahead Unit for 4 bits
module CLA4(output [3:0] sum, output cout, input [3:0] a, b, input cin);
  wire [3:0] g, p;
  wire [3:0] c;
  
  // Generate and Propagate
  assign g = a & b;
  assign p = a ^ b;
  
  // Carry calculation
  assign c[0] = cin;
  assign c[1] = g[0] | (p[0] & c[0]);
  assign c[2] = g[1] | (p[1] & g[0]) | (p[1] & p[0] & c[0]);
  assign c[3] = g[2] | (p[2] & g[1]) | (p[2] & p[1] & g[0]) | (p[2] & p[1] & p[0] & c[0]);
  assign cout = g[3] | (p[3] & g[2]) | (p[3] & p[2] & g[1]) | (p[3] & p[2] & p[1] & g[0]) | (p[3] & p[2] & p[1] & p[0] & c[0]);
  
  // Sum calculation
  assign sum = p ^ c;
  
endmodule

// 8-bit adder using two 4-bit CLA blocks
module adder8(output [7:0] sum, output cout, input [7:0] a, b);
  wire c4;
  
  CLA4 cla_low(sum[3:0], c4, a[3:0], b[3:0], 1'b0);
  CLA4 cla_high(sum[7:4], cout, a[7:4], b[7:4], c4);
  
endmodule