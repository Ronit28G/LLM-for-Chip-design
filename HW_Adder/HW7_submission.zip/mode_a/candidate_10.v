// Compact carry-skip adder with 4-bit blocks
module adder8(output [7:0] sum, output cout, input [7:0] a, b);
  wire [7:0] p, g;
  wire c4;
  
  // Generate and propagate
  assign p = a ^ b;
  assign g = a & b;
  
  // Block 0 (bits 0-3): ripple
  wire c1 = g[0];
  wire c2 = g[1] | (p[1] & c1);
  wire c3 = g[2] | (p[2] & c2);
  wire c4_internal = g[3] | (p[3] & c3);
  
  // Block propagate for block 0
  wire bp0 = p[3] & p[2] & p[1] & p[0];
  
  // Skip logic for block 0
  assign c4 = c4_internal;
  
  // Block 1 (bits 4-7): ripple
  wire c5 = g[4] | (p[4] & c4);
  wire c6 = g[5] | (p[5] & c5);
  wire c7 = g[6] | (p[6] & c6);
  
  // Sum
  assign sum[0] = p[0];
  assign sum[1] = p[1] ^ c1;
  assign sum[2] = p[2] ^ c2;
  assign sum[3] = p[3] ^ c3;
  assign sum[4] = p[4] ^ c4;
  assign sum[5] = p[5] ^ c5;
  assign sum[6] = p[6] ^ c6;
  assign sum[7] = p[7] ^ c7;
  
  assign cout = g[7] | (p[7] & c7);
endmodule