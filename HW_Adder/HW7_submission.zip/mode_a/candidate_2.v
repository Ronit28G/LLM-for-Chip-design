// Full Adder
module FA(output sum, cout, input a, b, cin);
  wire w0, w1, w2;
  
  xor  (w0, a, b);
  xor  (sum, w0, cin);
  
  and  (w1, w0, cin);
  and  (w2, a, b);
  or  (cout, w1, w2);
endmodule

// Ripple Carry Adder - 4 bits
module RCA4(output [3:0] sum, output cout, input [3:0] a, b, input cin);
  wire [2:0] c;
  
  FA fa0(sum[0], c[0], a[0], b[0], cin);
  FA fa1(sum[1], c[1], a[1], b[1], c[0]);
  FA fa2(sum[2], c[2], a[2], b[2], c[1]);
  FA fa3(sum[3], cout, a[3], b[3], c[2]);
endmodule

// 8-bit adder using two 4-bit RCA blocks
module adder8(output [7:0] sum, output cout, input [7:0] a, b);
  wire c4;
  
  RCA4 rca_low(sum[3:0], c4, a[3:0], b[3:0], 1'b0);
  RCA4 rca_high(sum[7:4], cout, a[7:4], b[7:4], c4);
endmodule