// Optimized Full Adder using assign statements
module FA(output sum, cout, input a, b, cin);
  assign sum = a ^ b ^ cin;
  assign cout = (a & b) | (cin & (a ^ b));
endmodule

// 8-bit Ripple Carry Adder
module adder8(output [7:0] sum, output cout, input [7:0] a, b);
  wire [6:0] c;
  
  FA fa0(sum[0], c[0], a[0], b[0], 1'b0);
  FA fa1(sum[1], c[1], a[1], b[1], c[0]);
  FA fa2(sum[2], c[2], a[2], b[2], c[1]);
  FA fa3(sum[3], c[3], a[3], b[3], c[2]);
  FA fa4(sum[4], c[4], a[4], b[4], c[3]);
  FA fa5(sum[5], c[5], a[5], b[5], c[4]);
  FA fa6(sum[6], c[6], a[6], b[6], c[5]);
  FA fa7(sum[7], cout, a[7], b[7], c[6]);
endmodule