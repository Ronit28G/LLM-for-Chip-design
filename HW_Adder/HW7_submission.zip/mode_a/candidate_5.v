// Minimal 8-bit adder - direct implementation
module adder8(output [7:0] sum, output cout, input [7:0] a, b);
  wire [6:0] c;
  wire [7:0] p;
  
  // Propagate
  assign p = a ^ b;
  
  // Carry chain
  assign c[0] = a[0] & b[0];
  assign c[1] = (a[1] & b[1]) | (p[1] & c[0]);
  assign c[2] = (a[2] & b[2]) | (p[2] & c[1]);
  assign c[3] = (a[3] & b[3]) | (p[3] & c[2]);
  assign c[4] = (a[4] & b[4]) | (p[4] & c[3]);
  assign c[5] = (a[5] & b[5]) | (p[5] & c[4]);
  assign c[6] = (a[6] & b[6]) | (p[6] & c[5]);
  assign cout = (a[7] & b[7]) | (p[7] & c[6]);
  
  // Sum
  assign sum[0] = p[0];
  assign sum[7:1] = p[7:1] ^ c[6:0];
endmodule