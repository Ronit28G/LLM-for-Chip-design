// Ultra-minimal 8-bit adder using behavioral modeling
module adder8(output [7:0] sum, output cout, input [7:0] a, b);
  assign {cout, sum} = a + b;
endmodule