// Kogge-Stone prefix adder with minimal area
module adder8(output [7:0] sum, output cout, input [7:0] a, b);
  wire [7:0] g0, p0;
  wire [7:0] g1, p1;
  wire [7:0] g2, p2;
  wire [7:0] g3;
  
  // Level 0: Generate and Propagate
  assign g0 = a & b;
  assign p0 = a ^ b;
  
  // Level 1: span 1
  assign g1[0] = g0[0];
  assign p1[0] = p0[0];
  assign g1[7:1] = g0[7:1] | (p0[7:1] & g0[6:0]);
  assign p1[7:1] = p0[7:1] & p0[6:0];
  
  // Level 2: span 2
  assign g2[1:0] = g1[1:0];
  assign p2[1:0] = p1[1:0];
  assign g2[7:2] = g1[7:2] | (p1[7:2] & g1[5:0]);
  assign p2[7:2] = p1[7:2] & p1[5:0];
  
  // Level 3: span 4
  assign g3[3:0] = g2[3:0];
  assign g3[7:4] = g2[7:4] | (p2[7:4] & g2[3:0]);
  
  // Sum and carry out
  assign sum[0] = p0[0];
  assign sum[7:1] = p0[7:1] ^ g3[6:0];
  assign cout = g3[7];
endmodule