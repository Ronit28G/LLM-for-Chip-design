// Hybrid adder: CLA for lower 6 bits, ripple for upper 2 bits
module adder8(output [7:0] sum, output cout, input [7:0] a, b);
  wire [5:0] g, p;
  wire [5:0] c;
  wire c6;
  
  // Generate and Propagate for bits 0-5
  assign g = a[5:0] & b[5:0];
  assign p = a[5:0] ^ b[5:0];
  
  // Carry lookahead for bits 0-5
  assign c[0] = g[0];
  assign c[1] = g[1] | (p[1] & g[0]);
  assign c[2] = g[2] | (p[2] & g[1]) | (p[2] & p[1] & g[0]);
  assign c[3] = g[3] | (p[3] & g[2]) | (p[3] & p[2] & g[1]) | (p[3] & p[2] & p[1] & g[0]);
  assign c[4] = g[4] | (p[4] & g[3]) | (p[4] & p[3] & g[2]) | (p[4] & p[3] & p[2] & g[1]) | (p[4] & p[3] & p[2] & p[1] & g[0]);
  assign c[5] = g[5] | (p[5] & g[4]) | (p[5] & p[4] & g[3]) | (p[5] & p[4] & p[3] & g[2]) | (p[5] & p[4] & p[3] & p[2] & g[1]) | (p[5] & p[4] & p[3] & p[2] & p[1] & g[0]);
  
  // Sum for bits 0-5
  assign sum[0] = p[0];
  assign sum[5:1] = p[5:1] ^ c[4:0];
  
  // Ripple carry for bits 6-7
  assign c6 = (a[6] & b[6]) | ((a[6] ^ b[6]) & c[5]);
  assign sum[6] = a[6] ^ b[6] ^ c[5];
  assign sum[7] = a[7] ^ b[7] ^ c6;
  assign cout = (a[7] & b[7]) | ((a[7] ^ b[7]) & c6);
endmodule