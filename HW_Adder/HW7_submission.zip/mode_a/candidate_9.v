// Minimal Brent-Kung parallel prefix adder
module adder8(output [7:0] sum, output cout, input [7:0] a, b);
  wire [7:0] g, p;
  wire [6:0] c;
  
  // Initial generate and propagate
  assign g = a & b;
  assign p = a ^ b;
  
  // Prefix computation - Brent-Kung style (reduced operators)
  // Level 1: compute carries for odd positions
  wire g1 = g[1] | (p[1] & g[0]);
  wire g3 = g[3] | (p[3] & g[2]);
  wire g5 = g[5] | (p[5] & g[4]);
  wire g7 = g[7] | (p[7] & g[6]);
  
  wire p1 = p[1] & p[0];
  wire p3 = p[3] & p[2];
  wire p5 = p[5] & p[4];
  wire p7 = p[7] & p[6];
  
  // Level 2: span 4
  wire g3_2 = g3 | (p3 & g1);
  wire g7_2 = g7 | (p7 & g5);
  wire p3_2 = p3 & p1;
  
  // Level 3: span 8
  wire g7_3 = g7_2 | (p7 & p5 & g3_2);
  
  // Carry computation
  assign c[0] = g[0];
  assign c[1] = g1;
  assign c[2] = g[2] | (p[2] & g1);
  assign c[3] = g3_2;
  assign c[4] = g[4] | (p[4] & g3_2);
  assign c[5] = g5 | (p5 & g3_2);
  assign c[6] = g[6] | (p[6] & (g5 | (p5 & g3_2)));
  
  // Sum and cout
  assign sum = p ^ {c[6:0], 1'b0};
  assign cout = g7_3;
endmodule