module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);

// Sparse tree adder - compute only essential carries, ripple between them
// 3-level tree depth with minimal gate count

wire [7:0] p, g;

assign p = a ^ b;
assign g = a & b;

// Level 1: Create 2-bit blocks
wire p10 = p[1] & p[0];
wire g10 = g[1] | (p[1] & g[0]);

wire p32 = p[3] & p[2];
wire g32 = g[3] | (p[3] & g[2]);

wire p54 = p[5] & p[4];
wire g54 = g[5] | (p[5] & g[4]);

wire p76 = p[7] & p[6];
wire g76 = g[7] | (p[7] & g[6]);

// Level 2: Merge to 4-bit blocks (only for positions we need)
wire p30 = p32 & p10;
wire g30 = g32 | (p32 & g10);

wire p74 = p76 & p54;
wire g74 = g76 | (p76 & g54);

// Level 3: Full 8-bit carry
wire c4 = g30;
wire cout_val = g74 | (p74 & g30);

// Ripple within blocks for remaining carries
wire c1 = g[0];
wire c2 = g10;
wire c3 = g[2] | (p[2] & c2);

wire c5 = g[4] | (p[4] & c4);
wire c6 = g54 | (p54 & c4);
wire c7 = g[6] | (p[6] & c6);

// Sum computation
assign sum[0] = p[0];
assign sum[1] = p[1] ^ c1;
assign sum[2] = p[2] ^ c2;
assign sum[3] = p[3] ^ c3;
assign sum[4] = p[4] ^ c4;
assign sum[5] = p[5] ^ c5;
assign sum[6] = p[6] ^ c6;
assign sum[7] = p[7] ^ c7;

assign cout = cout_val;

endmodule