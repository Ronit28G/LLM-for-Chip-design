module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);

// Kogge-Stone Parallel Prefix Adder
// Uses hierarchical generate/propagate computation with minimal depth

wire [7:0] p0, g0;
wire [7:0] p1, g1;
wire [7:0] p2, g2;
wire [7:0] p3, g3;

// Level 0: Initial propagate and generate
assign p0 = a ^ b;
assign g0 = a & b;

// Level 1: Span 1
assign p1[0] = p0[0];
assign g1[0] = g0[0];
assign p1[7:1] = p0[7:1] & p0[6:0];
assign g1[7:1] = g0[7:1] | (p0[7:1] & g0[6:0]);

// Level 2: Span 2
assign p2[1:0] = p1[1:0];
assign g2[1:0] = g1[1:0];
assign p2[7:2] = p1[7:2] & p1[5:0];
assign g2[7:2] = g1[7:2] | (p1[7:2] & g1[5:0]);

// Level 3: Span 4
assign p3[3:0] = p2[3:0];
assign g3[3:0] = g2[3:0];
assign p3[7:4] = p2[7:4] & p2[3:0];
assign g3[7:4] = g2[7:4] | (p2[7:4] & g2[3:0]);

// Final sum computation
assign sum[0] = p0[0];
assign sum[7:1] = p0[7:1] ^ g3[6:0];
assign cout = g3[7];

endmodule