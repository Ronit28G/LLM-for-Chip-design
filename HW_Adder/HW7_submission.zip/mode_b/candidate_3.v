module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);

// Hybrid 2-bit CLA blocks with minimal carry chain
// Uses 4 blocks of 2-bit CLA for reduced gate count

wire [7:0] p, g;
wire c2, c4, c6;

// Propagate and generate
assign p = a ^ b;
assign g = a & b;

// Block 0: bits 0-1
wire g0_1 = g[1] | (p[1] & g[0]);
assign sum[0] = p[0];
assign sum[1] = p[1] ^ g[0];
assign c2 = g0_1;

// Block 1: bits 2-3
wire g2_3 = g[3] | (p[3] & g[2]);
wire c3 = g[2] | (p[2] & c2);
assign sum[2] = p[2] ^ c2;
assign sum[3] = p[3] ^ c3;
assign c4 = g2_3 | (p[3] & p[2] & c2);

// Block 2: bits 4-5
wire g4_5 = g[5] | (p[5] & g[4]);
wire c5 = g[4] | (p[4] & c4);
assign sum[4] = p[4] ^ c4;
assign sum[5] = p[5] ^ c5;
assign c6 = g4_5 | (p[5] & p[4] & c4);

// Block 3: bits 6-7
wire g6_7 = g[7] | (p[7] & g[6]);
wire c7 = g[6] | (p[6] & c6);
assign sum[6] = p[6] ^ c6;
assign sum[7] = p[7] ^ c7;
assign cout = g6_7 | (p[7] & p[6] & c6);

endmodule