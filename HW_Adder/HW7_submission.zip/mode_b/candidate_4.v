module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);

// Brent-Kung Parallel Prefix Adder
// Reduced fanout with tree-based carry computation

wire [7:0] p, g;

// Level 0: propagate and generate
assign p = a ^ b;
assign g = a & b;

// Level 1: prefix pairs (0-1, 2-3, 4-5, 6-7)
wire p1_01 = p[1] & p[0];
wire g1_01 = g[1] | (p[1] & g[0]);

wire p1_23 = p[3] & p[2];
wire g1_23 = g[3] | (p[3] & g[2]);

wire p1_45 = p[5] & p[4];
wire g1_45 = g[5] | (p[5] & g[4]);

wire p1_67 = p[7] & p[6];
wire g1_67 = g[7] | (p[7] & g[6]);

// Level 2: prefix quads (0-3, 4-7)
wire p2_03 = p1_23 & p1_01;
wire g2_03 = g1_23 | (p1_23 & g1_01);

wire p2_47 = p1_67 & p1_45;
wire g2_47 = g1_67 | (p1_67 & g1_45);

// Level 3: prefix full (0-7)
wire g3_07 = g2_47 | (p2_47 & g2_03);

// Backward pass to get all carries
wire c1 = g[0];
wire c2 = g1_01;
wire c3 = g[2] | (p[2] & g1_01);
wire c4 = g2_03;
wire c5 = g[4] | (p[4] & g2_03);
wire c6 = g1_45 | (p1_45 & g2_03);
wire c7 = g[6] | (p[6] & c6);

// Sum computation
assign sum[0] = p[0];
assign sum[1] = p[1] ^ c1;
assign sum[2] = p[2] ^ c2;
assign sum[3] = p[3] ^ c3;
assign sum[4] = p[4] ^ c4;
assign sum[5] = p[5] ^ c5;
assign sum[6] = p[6] ^ c6;
assign sum[7] = p[7] ^ c7;
assign cout = g3_07;

endmodule