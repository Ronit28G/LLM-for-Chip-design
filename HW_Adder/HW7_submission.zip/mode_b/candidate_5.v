module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);

// Carry Select Adder with 4-bit blocks
// Precomputes carries for cin=0 and cin=1, then selects

wire [3:0] sum_low0, sum_high0, sum_high1;
wire cout_low0, cout_high0, cout_high1;

// Lower 4 bits - always cin=0
wire [3:0] p_low = a[3:0] ^ b[3:0];
wire [3:0] g_low = a[3:0] & b[3:0];

assign sum_low0[0] = p_low[0];
wire c1 = g_low[0];
assign sum_low0[1] = p_low[1] ^ c1;
wire c2 = g_low[1] | (p_low[1] & g_low[0]);
assign sum_low0[2] = p_low[2] ^ c2;
wire c3 = g_low[2] | (p_low[2] & g_low[1]) | (p_low[2] & p_low[1] & g_low[0]);
assign sum_low0[3] = p_low[3] ^ c3;
assign cout_low0 = g_low[3] | (p_low[3] & g_low[2]) | (p_low[3] & p_low[2] & g_low[1]) | (p_low[3] & p_low[2] & p_low[1] & g_low[0]);

// Upper 4 bits - cin=0 case
wire [3:0] p_high = a[7:4] ^ b[7:4];
wire [3:0] g_high = a[7:4] & b[7:4];

assign sum_high0[0] = p_high[0];
wire c5_0 = g_high[0];
assign sum_high0[1] = p_high[1] ^ c5_0;
wire c6_0 = g_high[1] | (p_high[1] & g_high[0]);
assign sum_high0[2] = p_high[2] ^ c6_0;
wire c7_0 = g_high[2] | (p_high[2] & g_high[1]) | (p_high[2] & p_high[1] & g_high[0]);
assign sum_high0[3] = p_high[3] ^ c7_0;
assign cout_high0 = g_high[3] | (p_high[3] & g_high[2]) | (p_high[3] & p_high[2] & g_high[1]) | (p_high[3] & p_high[2] & p_high[1] & g_high[0]);

// Upper 4 bits - cin=1 case
assign sum_high1[0] = ~p_high[0];
wire c5_1 = p_high[0] | g_high[0];
assign sum_high1[1] = p_high[1] ^ c5_1;
wire c6_1 = g_high[1] | (p_high[1] & p_high[0]) | (p_high[1] & g_high[0]);
assign sum_high1[2] = p_high[2] ^ c6_1;
wire c7_1 = g_high[2] | (p_high[2] & g_high[1]) | (p_high[2] & p_high[1] & p_high[0]) | (p_high[2] & p_high[1] & g_high[0]);
assign sum_high1[3] = p_high[3] ^ c7_1;
assign cout_high1 = g_high[3] | (p_high[3] & g_high[2]) | (p_high[3] & p_high[2] & g_high[1]) | (p_high[3] & p_high[2] & p_high[1] & p_high[0]) | (p_high[3] & p_high[2] & p_high[1] & g_high[0]);

// Select based on lower block carry
assign sum[3:0] = sum_low0;
assign sum[7:4] = cout_low0 ? sum_high1 : sum_high0;
assign cout = cout_low0 ? cout_high1 : cout_high0;

endmodule