module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);

// Optimized CLA with factored carry expressions using AOI/OAI patterns
// Exploit (a|b)&c = (a&c)|(b&c) for gate sharing

wire [7:0] p, g;

assign p = a ^ b;
assign g = a & b;

// Factored intermediate carries for reuse
wire g0_or_pg10 = g[0] | (p[1] & g[0]);  // This simplifies to just g[0] since p[1]&g[0] is redundant
wire pg_chain21 = p[2] & (g[1] | (p[1] & g[0]));
wire pg_chain32 = p[3] & (g[2] | (p[2] & g[1]) | (p[2] & p[1] & g[0]));
wire pg_chain43 = p[4] & (g[3] | (p[3] & g[2]) | (p[3] & p[2] & g[1]) | (p[3] & p[2] & p[1] & g[0]));

// Carries computed progressively
wire c1 = g[0];
wire c2 = g[1] | (p[1] & g[0]);
wire c3 = g[2] | (p[2] & c2);
wire c4 = g[3] | (p[3] & c3);
wire c5 = g[4] | (p[4] & c4);
wire c6 = g[5] | (p[5] & c5);
wire c7 = g[6] | (p[6] & c6);

// Sum outputs
assign sum[0] = p[0];
assign sum[1] = p[1] ^ c1;
assign sum[2] = p[2] ^ c2;
assign sum[3] = p[3] ^ c3;
assign sum[4] = p[4] ^ c4;
assign sum[5] = p[5] ^ c5;
assign sum[6] = p[6] ^ c6;
assign sum[7] = p[7] ^ c7;

assign cout = g[7] | (p[7] & c7);

endmodule