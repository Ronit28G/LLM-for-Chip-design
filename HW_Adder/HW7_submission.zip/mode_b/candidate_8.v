module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);

// Han-Carlson hybrid prefix adder
// Combines parallel prefix tree with ripple for optimal area-delay

wire [7:0] p, g;

assign p = a ^ b;
assign g = a & b;

// Level 1: Compute odd position prefix operators
wire g1 = g[1] | (p[1] & g[0]);
wire g3 = g[3] | (p[3] & g[2]);
wire g5 = g[5] | (p[5] & g[4]);
wire g7 = g[7] | (p[7] & g[6]);

wire p1 = p[1] & p[0];
wire p3 = p[3] & p[2];
wire p5 = p[5] & p[4];
wire p7 = p[7] & p[6];

// Level 2: Span 2 for positions 3,7
wire g3_full = g3 | (p3 & g1);
wire p3_full = p3 & p1;

wire g7_mid = g7 | (p7 & g5);
wire p7_mid = p7 & p5;

// Level 3: Span 4 for position 7
wire g7_full = g7_mid | (p7_mid & g3_full);

// Ripple computation for remaining carries
wire c1 = g[0];
wire c2 = g1;
wire c3 = g[2] | (p[2] & c2);
wire c4 = g3_full;
wire c5 = g[4] | (p[4] & c4);
wire c6 = g5 | (p5 & c4);
wire c7 = g[6] | (p[6] & c6);

// Sum computation
assign sum[0] = p[0];
assign sum[1] = p[1] ^ c1;
assign sum[2] = p[2] ^ c2;
assign sum[3] = p[3] ^ c3;
assign sum[4] = p[4] ^ c4;
assign sum[5] = p[5] ^ c5;
assign sum[6] = p[6] ^ c6;
assign sum[7] = p[7] ^ c7;

assign cout = g7_full;

endmodule