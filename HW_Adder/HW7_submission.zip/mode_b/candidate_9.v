module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);

// Condensed CLA using compound gate patterns
// Compute carries with direct AOI logic to reduce cell count

wire [7:0] p, g;
wire [7:0] c;

assign p = a ^ b;
assign g = a & b;

// Direct carry computation with optimized factoring
assign c[0] = 1'b0;
assign c[1] = g[0];
assign c[2] = g[1] | (p[1] & g[0]);
assign c[3] = g[2] | (p[2] & g[1]) | (p[2] & p[1] & g[0]);

// Middle section - use AOI pattern
wire g3_spread = g[3] | (p[3] & g[2]);
wire pg3210 = p[3] & p[2] & p[1] & g[0];
wire pg321 = p[3] & p[2] & g[1];
assign c[4] = g3_spread | pg321 | pg3210;

wire g4_spread = g[4] | (p[4] & g[3]);
wire pg4321 = p[4] & p[3] & p[2] & g[1];
wire pg43210 = p[4] & p[3] & p[2] & p[1] & g[0];
assign c[5] = g4_spread | (p[4] & pg321) | pg4321 | pg43210;

wire g5_spread = g[5] | (p[5] & g[4]);
wire pg543 = p[5] & p[4] & g[3];
wire pg5432 = p[5] & p[4] & p[3] & g[2];
assign c[6] = g5_spread | pg543 | pg5432 | (p[5] & pg4321) | (p[5] & pg43210);

wire g6_spread = g[6] | (p[6] & g[5]);
wire pg654 = p[6] & p[5] & g[4];
wire pg6543 = p[6] & p[5] & p[4] & g[3];
wire pg65432 = p[6] & p[5] & p[4] & p[3] & g[2];
assign c[7] = g6_spread | pg654 | pg6543 | pg65432 | (p[6] & p[5] & pg4321) | (p[6] & p[5] & pg43210);

wire g7_spread = g[7] | (p[7] & g[6]);
wire pg765 = p[7] & p[6] & g[5];
wire pg7654 = p[7] & p[6] & p[5] & g[4];
wire pg76543 = p[7] & p[6] & p[5] & p[4] & g[3];
wire pg765432 = p[7] & p[6] & p[5] & p[4] & p[3] & g[2];
assign cout = g7_spread | pg765 | pg7654 | pg76543 | pg765432 | (p[7] & p[6] & p[5] & pg4321) | (p[7] & p[6] & p[5] & pg43210);

assign sum = p ^ c;

endmodule