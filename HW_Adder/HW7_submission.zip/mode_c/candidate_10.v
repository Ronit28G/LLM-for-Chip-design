module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);

// Optimized prefix tree with explicit AOI/OAI pattern
// Minimize cells by structuring logic for compound gates

wire [7:0] p, g;

// Initial level
assign p = a ^ b;
assign g = a & b;

// Level 1: selective computation
wire g1, g3, g5, g7;
wire p3, p7;

assign g1 = g[1] | (p[1] & g[0]);
assign g3 = g[3] | (p[3] & g[2]);
assign p3 = p[3] & p[2];
assign g5 = g[5] | (p[5] & g[4]);
assign g7 = g[7] | (p[7] & g[6]);
assign p7 = p[7] & p[6];

// Level 2: span-2 nodes
wire g3_2, g7_2;
wire p7_2;

assign g3_2 = g3 | (p3 & g1);
assign g7_2 = g7 | (p7 & g5);
assign p7_2 = p7 & p[5] & p[4];

// Level 3: final span-4
wire g7_3;
assign g7_3 = g7_2 | (p7_2 & g3_2);

// Backfill carries with minimal gates
wire c2, c4, c5, c6;

// Use AOI structure: c2 = g[2] + p[2]*g1
assign c2 = g[2] | (p[2] & g1);

// Use AOI structure: c4 = g[4] + p[4]*g3_2
assign c4 = g[4] | (p[4] & g3_2);

// c5 uses compound: g5 + p[5]*p[4]*g3_2
assign c5 = g5 | (p[5] & p[4] & g3_2);

// c6 uses simple OR-AND
assign c6 = g[6] | (p[6] & c5);

// Sums
assign sum = p ^ {c6, c5, c4, g3_2, c2, g1, g[0], 1'b0};

assign cout = g7_3;

endmodule