module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);

// Kogge-Stone Parallel Prefix Adder - 8-bit
// Uses fewer levels than CLA but optimized for minimal cells

wire [7:0] p0, g0;
wire [7:1] p1, g1;
wire [7:2] p2, g2;
wire [7:4] p3, g3;

// Level 0: Initial propagate and generate
assign g0 = a & b;
assign p0 = a ^ b;

// Level 1: span 1
assign g1[1] = g0[1] | (p0[1] & g0[0]);
assign p1[1] = p0[1] & p0[0];
assign g1[2] = g0[2] | (p0[2] & g0[1]);
assign p1[2] = p0[2] & p0[1];
assign g1[3] = g0[3] | (p0[3] & g0[2]);
assign p1[3] = p0[3] & p0[2];
assign g1[4] = g0[4] | (p0[4] & g0[3]);
assign p1[4] = p0[4] & p0[3];
assign g1[5] = g0[5] | (p0[5] & g0[4]);
assign p1[5] = p0[5] & p0[4];
assign g1[6] = g0[6] | (p0[6] & g0[5]);
assign p1[6] = p0[6] & p0[5];
assign g1[7] = g0[7] | (p0[7] & g0[6]);
assign p1[7] = p0[7] & p0[6];

// Level 2: span 2
assign g2[2] = g1[2] | (p1[2] & g0[0]);
assign p2[2] = p1[2] & p0[0];
assign g2[3] = g1[3] | (p1[3] & g1[1]);
assign p2[3] = p1[3] & p1[1];
assign g2[4] = g1[4] | (p1[4] & g1[2]);
assign p2[4] = p1[4] & p1[2];
assign g2[5] = g1[5] | (p1[5] & g1[3]);
assign p2[5] = p1[5] & p1[3];
assign g2[6] = g1[6] | (p1[6] & g1[4]);
assign p2[6] = p1[6] & p1[4];
assign g2[7] = g1[7] | (p1[7] & g1[5]);
assign p2[7] = p1[7] & p1[5];

// Level 3: span 4
assign g3[4] = g2[4] | (p2[4] & g0[0]);
assign p3[4] = p2[4] & p0[0];
assign g3[5] = g2[5] | (p2[5] & g1[1]);
assign p3[5] = p2[5] & p1[1];
assign g3[6] = g2[6] | (p2[6] & g2[2]);
assign p3[6] = p2[6] & p2[2];
assign g3[7] = g2[7] | (p2[7] & g2[3]);
assign p3[7] = p2[7] & p2[3];

// Sum computation
assign sum[0] = p0[0];
assign sum[1] = p0[1] ^ g0[0];
assign sum[2] = p0[2] ^ g1[1];
assign sum[3] = p0[3] ^ g2[2];
assign sum[4] = p0[4] ^ g3[3];
assign sum[5] = p0[5] ^ g3[4];
assign sum[6] = p0[6] ^ g3[5];
assign sum[7] = p0[7] ^ g3[6];

assign cout = g3[7];

endmodule