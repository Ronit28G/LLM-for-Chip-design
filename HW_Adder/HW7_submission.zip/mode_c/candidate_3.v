module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);

// Brent-Kung Parallel Prefix Adder - 8-bit
// Uses fewer cells than Kogge-Stone by reducing wire fanout

wire [7:0] p, g;

// Level 0: Initial propagate and generate
assign g[0] = a[0] & b[0];
assign p[0] = a[0] | b[0];
assign g[1] = a[1] & b[1];
assign p[1] = a[1] | b[1];
assign g[2] = a[2] & b[2];
assign p[2] = a[2] | b[2];
assign g[3] = a[3] & b[3];
assign p[3] = a[3] | b[3];
assign g[4] = a[4] & b[4];
assign p[4] = a[4] | b[4];
assign g[5] = a[5] & b[5];
assign p[5] = a[5] | b[5];
assign g[6] = a[6] & b[6];
assign p[6] = a[6] | b[6];
assign g[7] = a[7] & b[7];
assign p[7] = a[7] | b[7];

// Prefix tree - forward pass (logarithmic)
wire [7:1] g1, p1;
assign g1[1] = g[1] | (p[1] & g[0]);
assign p1[1] = p[1] & p[0];
assign g1[3] = g[3] | (p[3] & g[2]);
assign p1[3] = p[3] & p[2];
assign g1[5] = g[5] | (p[5] & g[4]);
assign p1[5] = p[5] & p[4];
assign g1[7] = g[7] | (p[7] & g[6]);
assign p1[7] = p[7] & p[6];

wire [7:3] g2, p2;
assign g2[3] = g1[3] | (p1[3] & g1[1]);
assign p2[3] = p1[3] & p1[1];
assign g2[7] = g1[7] | (p1[7] & g1[5]);
assign p2[7] = p1[7] & p1[5];

wire g3_7, p3_7;
assign g3_7 = g2[7] | (p2[7] & g2[3]);
assign p3_7 = p2[7] & p2[3];

// Backward pass to fill intermediate carries
wire [6:2] c;
assign c[2] = g1[1] | (p1[1] & g[0]);
assign c[4] = g2[3] | (p2[3] & g1[1]);
assign c[6] = g2[7] | (p2[7] & g1[5]);

wire c3, c5;
assign c3 = g[3] | (p[3] & c[2]);
assign c5 = g[5] | (p[5] & c[4]);

// Sum outputs
assign sum[0] = a[0] ^ b[0];
assign sum[1] = a[1] ^ b[1] ^ g[0];
assign sum[2] = a[2] ^ b[2] ^ g1[1];
assign sum[3] = a[3] ^ b[3] ^ c[2];
assign sum[4] = a[4] ^ b[4] ^ g2[3];
assign sum[5] = a[5] ^ b[5] ^ c[4];
assign sum[6] = a[6] ^ b[6] ^ g2[7];
assign sum[7] = a[7] ^ b[7] ^ c[6];

assign cout = g3_7;

endmodule