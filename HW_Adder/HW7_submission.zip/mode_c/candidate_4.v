module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);

// Hybrid Carry Select Adder - 8-bit
// Split into two 4-bit blocks with dual computation

// Lower 4 bits - simple ripple
wire [3:0] sum_low;
wire c4;

wire g0, p0, c1;
wire g1, p1, c2;
wire g2, p2, c3;
wire g3, p3;

assign g0 = a[0] & b[0];
assign p0 = a[0] ^ b[0];
assign sum_low[0] = p0;

assign g1 = a[1] & b[1];
assign p1 = a[1] ^ b[1];
assign c1 = g0;
assign sum_low[1] = p1 ^ c1;

assign g2 = a[2] & b[2];
assign p2 = a[2] ^ b[2];
assign c2 = g1 | (p1 & g0);
assign sum_low[2] = p2 ^ c2;

assign g3 = a[3] & b[3];
assign p3 = a[3] ^ b[3];
assign c3 = g2 | (p2 & g1) | (p2 & p1 & g0);
assign sum_low[3] = p3 ^ c3;

assign c4 = g3 | (p3 & g2) | (p3 & p2 & g1) | (p3 & p2 & p1 & g0);

// Upper 4 bits - assume cin=0
wire [3:0] sum_hi0;
wire g4_0, p4_0, c5_0;
wire g5_0, p5_0, c6_0;
wire g6_0, p6_0, c7_0;
wire g7_0, p7_0, cout_0;

assign g4_0 = a[4] & b[4];
assign p4_0 = a[4] ^ b[4];
assign sum_hi0[0] = p4_0;

assign g5_0 = a[5] & b[5];
assign p5_0 = a[5] ^ b[5];
assign c5_0 = g4_0;
assign sum_hi0[1] = p5_0 ^ c5_0;

assign g6_0 = a[6] & b[6];
assign p6_0 = a[6] ^ b[6];
assign c6_0 = g5_0 | (p5_0 & g4_0);
assign sum_hi0[2] = p6_0 ^ c6_0;

assign g7_0 = a[7] & b[7];
assign p7_0 = a[7] ^ b[7];
assign c7_0 = g6_0 | (p6_0 & g5_0) | (p6_0 & p5_0 & g4_0);
assign sum_hi0[3] = p7_0 ^ c7_0;

assign cout_0 = g7_0 | (p7_0 & g6_0) | (p7_0 & p6_0 & g5_0) | (p7_0 & p6_0 & p5_0 & g4_0);

// Upper 4 bits - assume cin=1
wire [3:0] sum_hi1;
wire cout_1;

assign sum_hi1[0] = ~p4_0;
assign sum_hi1[1] = p5_0 ^ (~g4_0);
assign sum_hi1[2] = p6_0 ^ (g5_0 | (~p5_0 & ~g4_0));
assign sum_hi1[3] = p7_0 ^ (g6_0 | (p6_0 & g5_0) | (p6_0 & ~p5_0 & ~g4_0));

assign cout_1 = g7_0 | (p7_0 & g6_0) | (p7_0 & p6_0 & g5_0) | (p7_0 & p6_0 & ~p5_0 & ~g4_0);

// Multiplex based on c4
assign sum[3:0] = sum_low;
assign sum[7:4] = c4 ? sum_hi1 : sum_hi0;
assign cout = c4 ? cout_1 : cout_0;

endmodule