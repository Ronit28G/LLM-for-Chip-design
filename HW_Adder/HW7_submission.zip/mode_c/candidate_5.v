module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);

// Han-Carlson Parallel Prefix Adder - 8-bit
// Hybrid between Kogge-Stone and Brent-Kung
// Optimized for minimal cell count with acceptable delay

wire [7:0] p, g;

// Initial generate and propagate
assign g = a & b;
assign p = a ^ b;

// Level 1: All odd positions
wire [7:1] g1;
assign g1[1] = g[1] | (p[1] & g[0]);
assign g1[3] = g[3] | (p[3] & g[2]);
assign g1[5] = g[5] | (p[5] & g[4]);
assign g1[7] = g[7] | (p[7] & g[6]);

// Level 2: Positions 3 and 7
wire g2_3, g2_7;
assign g2_3 = g1[3] | (p[3] & p[2] & g1[1]);
assign g2_7 = g1[7] | (p[7] & p[6] & g1[5]);

// Level 3: Position 7
wire g3_7;
assign g3_7 = g2_7 | (p[7] & p[6] & p[5] & p[4] & g2_3);

// Level 4: Fill remaining positions (backward pass)
wire g4_2, g4_4, g4_5, g4_6;
assign g4_2 = g[2] | (p[2] & g1[1]);
assign g4_4 = g[4] | (p[4] & g2_3);
assign g4_5 = g1[5] | (p[5] & p[4] & g2_3);
assign g4_6 = g[6] | (p[6] & g4_5);

// Sum computation using minimal XOR gates
assign sum[0] = p[0];
assign sum[1] = p[1] ^ g[0];
assign sum[2] = p[2] ^ g1[1];
assign sum[3] = p[3] ^ g4_2;
assign sum[4] = p[4] ^ g2_3;
assign sum[5] = p[5] ^ g4_4;
assign sum[6] = p[6] ^ g4_5;
assign sum[7] = p[7] ^ g4_6;

assign cout = g3_7;

endmodule