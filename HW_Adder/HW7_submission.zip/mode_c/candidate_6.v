module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);

// Conditional sum adder - 8-bit with optimized structure
// Uses smaller blocks to minimize cell count

// Block 0: bits 0-1 (unconditional)
wire p0, g0, p1, g1;
wire c1, s0, s1;

assign p0 = a[0] ^ b[0];
assign g0 = a[0] & b[0];
assign s0 = p0;

assign p1 = a[1] ^ b[1];
assign g1 = a[1] & b[1];
assign c1 = g0;
assign s1 = p1 ^ c1;

wire c2;
assign c2 = g1 | (p1 & g0);

// Block 1: bits 2-3 (conditional on c2)
wire p2, g2, p3, g3;
wire s2_0, s3_0, c4_0;
wire s2_1, s3_1, c4_1;

assign p2 = a[2] ^ b[2];
assign g2 = a[2] & b[2];
assign p3 = a[3] ^ b[3];
assign g3 = a[3] & b[3];

assign s2_0 = p2;
assign s3_0 = p3 ^ g2;
assign c4_0 = g3 | (p3 & g2);

assign s2_1 = ~p2;
assign s3_1 = p3 ^ (~g2);
assign c4_1 = g3 | (p3 & ~g2);

wire s2, s3, c4;
assign s2 = c2 ? s2_1 : s2_0;
assign s3 = c2 ? s3_1 : s3_0;
assign c4 = c2 ? c4_1 : c4_0;

// Block 2: bits 4-7 (conditional on c4)
wire p4, g4, p5, g5, p6, g6, p7, g7;
wire s4_0, s5_0, s6_0, s7_0, cout_0;
wire s4_1, s5_1, s6_1, s7_1, cout_1;

assign p4 = a[4] ^ b[4];
assign g4 = a[4] & b[4];
assign p5 = a[5] ^ b[5];
assign g5 = a[5] & b[5];
assign p6 = a[6] ^ b[6];
assign g6 = a[6] & b[6];
assign p7 = a[7] ^ b[7];
assign g7 = a[7] & b[7];

assign s4_0 = p4;
assign s5_0 = p5 ^ g4;
assign s6_0 = p6 ^ (g5 | (p5 & g4));
assign s7_0 = p7 ^ (g6 | (p6 & g5) | (p6 & p5 & g4));
assign cout_0 = g7 | (p7 & g6) | (p7 & p6 & g5) | (p7 & p6 & p5 & g4);

assign s4_1 = ~p4;
assign s5_1 = p5 ^ (~g4);
assign s6_1 = p6 ^ (g5 | (p5 & ~g4));
assign s7_1 = p7 ^ (g6 | (p6 & g5) | (p6 & p5 & ~g4));
assign cout_1 = g7 | (p7 & g6) | (p7 & p6 & g5) | (p7 & p6 & p5 & ~g4);

assign sum[0] = s0;
assign sum[1] = s1;
assign sum[2] = s2;
assign sum[3] = s3;
assign sum[4] = c4 ? s4_1 : s4_0;
assign sum[5] = c4 ? s5_1 : s5_0;
assign sum[6] = c4 ? s6_1 : s6_0;
assign sum[7] = c4 ? s7_1 : s7_0;
assign cout = c4 ? cout_1 : cout_0;

endmodule