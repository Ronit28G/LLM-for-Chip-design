module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);

// Sparse Kogge-Stone with minimal fanout - 8-bit
// Compute only essential intermediate carries

wire [7:0] p, g;

// Level 0: propagate and generate
assign p = a ^ b;
assign g = a & b;

// Level 1: span 1 (only positions we need)
wire g1_1, g1_3, g1_5, g1_7;
wire p1_3, p1_7;

assign g1_1 = g[1] | (p[1] & g[0]);
assign g1_3 = g[3] | (p[3] & g[2]);
assign p1_3 = p[3] & p[2];
assign g1_5 = g[5] | (p[5] & g[4]);
assign g1_7 = g[7] | (p[7] & g[6]);
assign p1_7 = p[7] & p[6];

// Level 2: span 2
wire g2_3, g2_7;
wire p2_7;

assign g2_3 = g1_3 | (p1_3 & g1_1);
assign g2_7 = g1_7 | (p1_7 & g1_5);
assign p2_7 = p1_7 & p[5] & p[4];

// Level 3: span 4
wire g3_7;

assign g3_7 = g2_7 | (p2_7 & g2_3);

// Derive missing carries in reverse
wire c2, c4, c5, c6;

assign c2 = g[2] | (p[2] & g1_1);
assign c4 = g[4] | (p[4] & g2_3);
assign c5 = g1_5 | (p[5] & p[4] & g2_3);
assign c6 = g[6] | (p[6] & c5);

// Sum computation
assign sum[0] = p[0];
assign sum[1] = p[1] ^ g[0];
assign sum[2] = p[2] ^ g1_1;
assign sum[3] = p[3] ^ c2;
assign sum[4] = p[4] ^ g2_3;
assign sum[5] = p[5] ^ c4;
assign sum[6] = p[6] ^ c5;
assign sum[7] = p[7] ^ c6;

assign cout = g3_7;

endmodule