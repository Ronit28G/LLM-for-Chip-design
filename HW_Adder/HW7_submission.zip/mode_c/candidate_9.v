module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);

// Hybrid ripple-carry with 2-bit lookahead blocks
// Minimizes cell count by balancing ripple and lookahead

wire [7:0] p, g;
assign p = a ^ b;
assign g = a & b;

// Block 0: bits 0-1
wire c1, c2;
assign c1 = g[0];
assign c2 = g[1] | (p[1] & g[0]);

// Block 1: bits 2-3 with lookahead
wire c3, c4;
assign c3 = g[2] | (p[2] & c2);
assign c4 = g[3] | (p[3] & g[2]) | (p[3] & p[2] & c2);

// Block 2: bits 4-5 with lookahead
wire c5, c6;
assign c5 = g[4] | (p[4] & c4);
assign c6 = g[5] | (p[5] & g[4]) | (p[5] & p[4] & c4);

// Block 3: bits 6-7 with lookahead
wire c7;
assign c7 = g[6] | (p[6] & c6);
assign cout = g[7] | (p[7] & g[6]) | (p[7] & p[6] & c6);

// Sum outputs
assign sum[0] = p[0];
assign sum[1] = p[1] ^ c1;
assign sum[2] = p[2] ^ c2;
assign sum[3] = p[3] ^ c3;
assign sum[4] = p[4] ^ c4;
assign sum[5] = p[5] ^ c5;
assign sum[6] = p[6] ^ c6;
assign sum[7] = p[7] ^ c7;

endmodule