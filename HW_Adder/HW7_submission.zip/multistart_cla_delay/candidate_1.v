module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);
    wire [7:0] g;
    wire [7:0] p;
    wire [3:0] gg;
    wire [3:0] gp;
    wire [7:0] c;
    
    // Level 1: Generate and Propagate for each bit
    assign g[0] = a[0] & b[0];
    assign p[0] = a[0] ^ b[0];
    assign g[1] = a[1] & b[1];
    assign p[1] = a[1] ^ b[1];
    assign g[2] = a[2] & b[2];
    assign p[2] = a[2] ^ b[2];
    assign g[3] = a[3] & b[3];
    assign p[3] = a[3] ^ b[3];
    assign g[4] = a[4] & b[4];
    assign p[4] = a[4] ^ b[4];
    assign g[5] = a[5] & b[5];
    assign p[5] = a[5] ^ b[5];
    assign g[6] = a[6] & b[6];
    assign p[6] = a[6] ^ b[6];
    assign g[7] = a[7] & b[7];
    assign p[7] = a[7] ^ b[7];
    
    // Level 2: Group generate and propagate for 2-bit blocks
    assign gg[0] = g[1] | (p[1] & g[0]);
    assign gp[0] = p[1] & p[0];
    assign gg[1] = g[3] | (p[3] & g[2]);
    assign gp[1] = p[3] & p[2];
    assign gg[2] = g[5] | (p[5] & g[4]);
    assign gp[2] = p[5] & p[4];
    assign gg[3] = g[7] | (p[7] & g[6]);
    assign gp[3] = p[7] & p[6];
    
    // Level 3: Carries using hierarchical structure
    assign c[0] = 1'b0;
    assign c[1] = g[0];
    assign c[2] = gg[0];
    assign c[3] = g[2] | (p[2] & gg[0]);
    assign c[4] = gg[1] | (gp[1] & gg[0]);
    assign c[5] = g[4] | (p[4] & gg[1]) | (p[4] & gp[1] & gg[0]);
    assign c[6] = gg[2] | (gp[2] & gg[1]) | (gp[2] & gp[1] & gg[0]);
    assign c[7] = g[6] | (p[6] & gg[2]) | (p[6] & gp[2] & gg[1]) | (p[6] & gp[2] & gp[1] & gg[0]);
    assign cout = gg[3] | (gp[3] & gg[2]) | (gp[3] & gp[2] & gg[1]) | (gp[3] & gp[2] & gp[1] & gg[0]);
    
    // Level 4: Sum computation
    assign sum[0] = p[0];
    assign sum[1] = p[1] ^ c[1];
    assign sum[2] = p[2] ^ c[2];
    assign sum[3] = p[3] ^ c[3];
    assign sum[4] = p[4] ^ c[4];
    assign sum[5] = p[5] ^ c[5];
    assign sum[6] = p[6] ^ c[6];
    assign sum[7] = p[7] ^ c[7];
endmodule