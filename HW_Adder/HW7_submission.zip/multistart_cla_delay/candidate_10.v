module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);
    // Tree adder with 2-level lookahead: 2-bit blocks then global
    wire [7:0] p, g;
    
    assign p = a ^ b;
    assign g = a & b;
    
    // Level 1: 2-bit block generates and propagates
    wire gg0, gp0, gg1, gp1, gg2, gp2, gg3, gp3;
    
    assign gg0 = g[1] | (p[1] & g[0]);
    assign gp0 = p[1] & p[0];
    
    assign gg1 = g[3] | (p[3] & g[2]);
    assign gp1 = p[3] & p[2];
    
    assign gg2 = g[5] | (p[5] & g[4]);
    assign gp2 = p[5] & p[4];
    
    assign gg3 = g[7] | (p[7] & g[6]);
    assign gp3 = p[7] & p[6];
    
    // Level 2: Global carries between blocks
    wire c2, c4, c6;
    
    assign c2 = gg1 | (gp1 & gg0);
    assign c4 = gg2 | (gp2 & c2);
    assign c6 = gg3 | (gp3 & c4);
    
    // Level 3: Local carries within blocks
    wire c1, c3, c5;
    
    assign c1 = gg0;
    assign c3 = g[2] | (p[2] & c2);
    assign c5 = g[4] | (p[4] & c4);
    
    // Final sum
    assign sum[0] = p[0];
    assign sum[1] = p[1] ^ g[0];
    assign sum[2] = p[2] ^ c1;
    assign sum[3] = p[3] ^ c3;
    assign sum[4] = p[4] ^ c2;
    assign sum[5] = p[5] ^ c5;
    assign sum[6] = p[6] ^ c4;
    assign sum[7] = p[7] ^ c6;
    assign cout = g[6] | (p[6] & c6);
    
endmodule