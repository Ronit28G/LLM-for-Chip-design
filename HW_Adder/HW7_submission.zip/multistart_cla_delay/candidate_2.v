module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);
    wire [7:0] p, g;
    wire [6:0] c;
    
    // Level 1: Initial P and G
    assign p[0] = a[0] ^ b[0];
    assign g[0] = a[0] & b[0];
    assign p[1] = a[1] ^ b[1];
    assign g[1] = a[1] & b[1];
    assign p[2] = a[2] ^ b[2];
    assign g[2] = a[2] & b[2];
    assign p[3] = a[3] ^ b[3];
    assign g[3] = a[3] & b[3];
    assign p[4] = a[4] ^ b[4];
    assign g[4] = a[4] & b[4];
    assign p[5] = a[5] ^ b[5];
    assign g[5] = a[5] & b[5];
    assign p[6] = a[6] ^ b[6];
    assign g[6] = a[6] & b[6];
    assign p[7] = a[7] ^ b[7];
    assign g[7] = a[7] & b[7];
    
    // Brent-Kung prefix tree (sparse)
    // Level 2: span 2
    wire g1_0, p1_0, g1_2, p1_2, g1_4, p1_4, g1_6, p1_6;
    assign g1_0 = g[1] | (p[1] & g[0]);
    assign p1_0 = p[1] & p[0];
    assign g1_2 = g[3] | (p[3] & g[2]);
    assign p1_2 = p[3] & p[2];
    assign g1_4 = g[5] | (p[5] & g[4]);
    assign p1_4 = p[5] & p[4];
    assign g1_6 = g[7] | (p[7] & g[6]);
    assign p1_6 = p[7] & p[6];
    
    // Level 3: span 4
    wire g2_2, p2_2, g2_6, p2_6;
    assign g2_2 = g1_2 | (p1_2 & g1_0);
    assign p2_2 = p1_2 & p1_0;
    assign g2_6 = g1_6 | (p1_6 & g1_4);
    assign p2_6 = p1_6 & p1_4;
    
    // Level 4: span 8
    wire g3_6, p3_6;
    assign g3_6 = g2_6 | (p2_6 & g2_2);
    assign p3_6 = p2_6 & p2_2;
    
    // Level 5: Back propagation for missing carries
    assign c[0] = g[0];
    assign c[1] = g1_0;
    assign c[2] = g[2] | (p[2] & g1_0);
    assign c[3] = g2_2;
    assign c[4] = g[4] | (p[4] & g2_2);
    assign c[5] = g1_4 | (p1_4 & g2_2);
    assign c[6] = g[6] | (p[6] & g1_4) | (p[6] & p1_4 & g2_2);
    
    // Level 6: Final sum and cout
    assign sum[0] = p[0];
    assign sum[1] = p[1] ^ c[0];
    assign sum[2] = p[2] ^ c[1];
    assign sum[3] = p[3] ^ c[2];
    assign sum[4] = p[4] ^ c[3];
    assign sum[5] = p[5] ^ c[4];
    assign sum[6] = p[6] ^ c[5];
    assign sum[7] = p[7] ^ c[6];
    assign cout = g3_6;
    
endmodule