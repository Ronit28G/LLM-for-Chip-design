module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);
    // Carry-select architecture with 2-2-2-2 split
    wire [1:0] sum0_0, sum0_1, sum1_0, sum1_1, sum2_0, sum2_1, sum3_0, sum3_1;
    wire c0_0, c0_1, c1_0, c1_1, c2_0, c2_1, c3_0, c3_1;
    wire sel1, sel2, sel3;
    
    // Block 0 (bits 0-1): assume cin=0
    assign sum0_0[0] = a[0] ^ b[0];
    assign c0_0 = a[0] & b[0];
    assign sum0_0[1] = a[1] ^ b[1] ^ c0_0;
    assign c0_1 = (a[1] & b[1]) | (c0_0 & (a[1] ^ b[1]));
    
    // Block 1 (bits 2-3): compute for cin=0 and cin=1
    assign sum1_0[0] = a[2] ^ b[2];
    wire g1_0 = a[2] & b[2];
    assign sum1_0[1] = a[3] ^ b[3] ^ g1_0;
    assign c1_0 = (a[3] & b[3]) | (g1_0 & (a[3] ^ b[3]));
    
    wire p2 = a[2] ^ b[2];
    assign sum1_1[0] = ~p2;
    wire g1_1 = a[2] | b[2];
    assign sum1_1[1] = a[3] ^ b[3] ^ g1_1;
    assign c1_1 = (a[3] & b[3]) | (g1_1 & (a[3] ^ b[3]));
    
    assign sel1 = c0_1;
    
    // Block 2 (bits 4-5): compute for cin=0 and cin=1
    assign sum2_0[0] = a[4] ^ b[4];
    wire g2_0 = a[4] & b[4];
    assign sum2_0[1] = a[5] ^ b[5] ^ g2_0;
    assign c2_0 = (a[5] & b[5]) | (g2_0 & (a[5] ^ b[5]));
    
    wire p4 = a[4] ^ b[4];
    assign sum2_1[0] = ~p4;
    wire g2_1 = a[4] | b[4];
    assign sum2_1[1] = a[5] ^ b[5] ^ g2_1;
    assign c2_1 = (a[5] & b[5]) | (g2_1 & (a[5] ^ b[5]));
    
    assign sel2 = sel1 ? c1_1 : c1_0;
    
    // Block 3 (bits 6-7): compute for cin=0 and cin=1
    assign sum3_0[0] = a[6] ^ b[6];
    wire g3_0 = a[6] & b[6];
    assign sum3_0[1] = a[7] ^ b[7] ^ g3_0;
    assign c3_0 = (a[7] & b[7]) | (g3_0 & (a[7] ^ b[7]));
    
    wire p6 = a[6] ^ b[6];
    assign sum3_1[0] = ~p6;
    wire g3_1 = a[6] | b[6];
    assign sum3_1[1] = a[7] ^ b[7] ^ g3_1;
    assign c3_1 = (a[7] & b[7]) | (g3_1 & (a[7] ^ b[7]));
    
    assign sel3 = sel2 ? c2_1 : c2_0;
    
    // Output selection
    assign sum[1:0] = sum0_0;
    assign sum[3:2] = sel1 ? sum1_1 : sum1_0;
    assign sum[5:4] = sel2 ? sum2_1 : sum2_0;
    assign sum[7:6] = sel3 ? sum3_1 : sum3_0;
    assign cout = sel3 ? c3_1 : c3_0;
    
endmodule