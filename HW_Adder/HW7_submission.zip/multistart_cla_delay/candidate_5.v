module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);
    // Hybrid: 4-bit CLA blocks with ripple between blocks
    wire [7:0] p, g;
    wire c4;
    wire [3:0] c_low, c_high;
    
    // Generate P and G for all bits
    assign p = a ^ b;
    assign g = a & b;
    
    // Lower 4-bit CLA block (bits 0-3)
    wire g0_1, g0_2, g0_3;
    wire p0_1, p0_2, p0_3;
    
    assign c_low[0] = 1'b0;
    assign c_low[1] = g[0];
    
    assign g0_1 = g[1] | (p[1] & g[0]);
    assign c_low[2] = g0_1;
    
    assign p0_2 = p[2] & p[1];
    assign g0_2 = g[2] | (p[2] & g[1]) | (p0_2 & g[0]);
    assign c_low[3] = g0_2;
    
    assign p0_3 = p[3] & p[2] & p[1];
    assign g0_3 = g[3] | (p[3] & g[2]) | (p[3] & p[2] & g[1]) | (p0_3 & g[0]);
    assign c4 = g0_3;
    
    // Upper 4-bit CLA block (bits 4-7) with c4 as input
    wire g4_5, g4_6, g4_7;
    wire p4_5, p4_6, p4_7;
    
    assign c_high[0] = c4;
    assign c_high[1] = g[4] | (p[4] & c4);
    
    assign g4_5 = g[5] | (p[5] & g[4]);
    assign p4_5 = p[5] & p[4];
    assign c_high[2] = g4_5 | (p4_5 & c4);
    
    assign p4_6 = p[6] & p[5];
    assign g4_6 = g[6] | (p[6] & g[5]) | (p4_6 & g[4]);
    assign c_high[3] = g4_6 | (p4_6 & p[4] & c4);
    
    assign p4_7 = p[7] & p[6] & p[5];
    assign g4_7 = g[7] | (p[7] & g[6]) | (p[7] & p[6] & g[5]) | (p4_7 & g[4]);
    assign cout = g4_7 | (p4_7 & p[4] & c4);
    
    // Compute sum
    assign sum[0] = p[0];
    assign sum[1] = p[1] ^ c_low[1];
    assign sum[2] = p[2] ^ c_low[2];
    assign sum[3] = p[3] ^ c_low[3];
    assign sum[4] = p[4] ^ c_high[0];
    assign sum[5] = p[5] ^ c_high[1];
    assign sum[6] = p[6] ^ c_high[2];
    assign sum[7] = p[7] ^ c_high[3];
    
endmodule