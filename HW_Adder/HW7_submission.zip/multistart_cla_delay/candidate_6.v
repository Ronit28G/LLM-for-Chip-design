module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);
    // Direct AOI/OAI gate implementation to minimize cells and depth
    wire [7:0] p;
    wire [6:0] c;
    
    // Propagate (XOR for sum later)
    assign p = a ^ b;
    
    // Carry chain using AOI/OAI logic
    // c[0] = a[0] & b[0]
    assign c[0] = a[0] & b[0];
    
    // c[1] = (a[1] & b[1]) | (a[1] & c[0]) | (b[1] & c[0])
    //      = (a[1] & b[1]) | ((a[1] | b[1]) & c[0])
    assign c[1] = (a[1] & b[1]) | ((a[1] | b[1]) & c[0]);
    
    // c[2] using AOI
    assign c[2] = (a[2] & b[2]) | ((a[2] | b[2]) & c[1]);
    
    // c[3] using AOI
    assign c[3] = (a[3] & b[3]) | ((a[3] | b[3]) & c[2]);
    
    // c[4] using AOI
    assign c[4] = (a[4] & b[4]) | ((a[4] | b[4]) & c[3]);
    
    // c[5] using AOI
    assign c[5] = (a[5] & b[5]) | ((a[5] | b[5]) & c[4]);
    
    // c[6] using AOI
    assign c[6] = (a[6] & b[6]) | ((a[6] | b[6]) & c[5]);
    
    // cout using AOI
    assign cout = (a[7] & b[7]) | ((a[7] | b[7]) & c[6]);
    
    // Sum computation
    assign sum[0] = p[0];
    assign sum[1] = p[1] ^ c[0];
    assign sum[2] = p[2] ^ c[1];
    assign sum[3] = p[3] ^ c[2];
    assign sum[4] = p[4] ^ c[3];
    assign sum[5] = p[5] ^ c[4];
    assign sum[6] = p[6] ^ c[5];
    assign sum[7] = p[7] ^ c[6];
    
endmodule