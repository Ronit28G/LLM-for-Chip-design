module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);
    // Han-Carlson tree: sparse outputs, minimal fanout
    wire [7:0] p, g;
    
    // Level 0: P and G
    assign p = a ^ b;
    assign g = a & b;
    
    // Level 1: span 1 (pairs)
    wire g1_1, g1_3, g1_5, g1_7;
    wire p1_1, p1_3, p1_5, p1_7;
    
    assign g1_1 = g[1] | (p[1] & g[0]);
    assign p1_1 = p[1] & p[0];
    assign g1_3 = g[3] | (p[3] & g[2]);
    assign p1_3 = p[3] & p[2];
    assign g1_5 = g[5] | (p[5] & g[4]);
    assign p1_5 = p[5] & p[4];
    assign g1_7 = g[7] | (p[7] & g[6]);
    assign p1_7 = p[7] & p[6];
    
    // Level 2: span 2 (quads)
    wire g2_3, g2_7;
    wire p2_3, p2_7;
    
    assign g2_3 = g1_3 | (p1_3 & g1_1);
    assign p2_3 = p1_3 & p1_1;
    assign g2_7 = g1_7 | (p1_7 & g1_5);
    assign p2_7 = p1_7 & p1_5;
    
    // Level 3: span 4 (octets)
    wire g3_7;
    
    assign g3_7 = g2_7 | (p2_7 & g2_3);
    
    // Level 4: Fill in missing carries
    wire c1, c2, c3, c4, c5, c6;
    
    assign c1 = g1_1;
    assign c2 = g[2] | (p[2] & g1_1);
    assign c3 = g2_3;
    assign c4 = g[4] | (p[4] & g2_3);
    assign c5 = g1_5 | (p1_5 & g2_3);
    assign c6 = g[6] | (p[6] & g1_5) | (p[6] & p1_5 & g2_3);
    
    // Sum
    assign sum[0] = p[0];
    assign sum[1] = p[1] ^ g[0];
    assign sum[2] = p[2] ^ c1;
    assign sum[3] = p[3] ^ c2;
    assign sum[4] = p[4] ^ c3;
    assign sum[5] = p[5] ^ c4;
    assign sum[6] = p[6] ^ c5;
    assign sum[7] = p[7] ^ c6;
    assign cout = g3_7;
    
endmodule