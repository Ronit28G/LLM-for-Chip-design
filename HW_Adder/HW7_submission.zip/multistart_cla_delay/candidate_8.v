module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);
    // Conditional sum adder with aggressive 2-bit grouping
    wire [7:0] p, g;
    
    assign p = a ^ b;
    assign g = a & b;
    
    // Group 0: bits 0-1 (fixed cin=0)
    wire c1_g0;
    assign sum[0] = p[0];
    assign c1_g0 = g[0];
    assign sum[1] = p[1] ^ c1_g0;
    wire cout_g0 = g[1] | (p[1] & c1_g0);
    
    // Group 1: bits 2-3 (dual-rail: cin=0, cin=1)
    wire s2_0, s3_0, co_g1_0;
    wire s2_1, s3_1, co_g1_1;
    
    assign s2_0 = p[2];
    assign s3_0 = p[3] ^ g[2];
    assign co_g1_0 = g[3] | (p[3] & g[2]);
    
    assign s2_1 = ~p[2];
    wire cin1_to_3 = g[2] | p[2];
    assign s3_1 = p[3] ^ cin1_to_3;
    assign co_g1_1 = g[3] | (p[3] & cin1_to_3);
    
    assign sum[2] = cout_g0 ? s2_1 : s2_0;
    assign sum[3] = cout_g0 ? s3_1 : s3_0;
    wire cout_g1 = cout_g0 ? co_g1_1 : co_g1_0;
    
    // Group 2: bits 4-5 (dual-rail)
    wire s4_0, s5_0, co_g2_0;
    wire s4_1, s5_1, co_g2_1;
    
    assign s4_0 = p[4];
    assign s5_0 = p[5] ^ g[4];
    assign co_g2_0 = g[5] | (p[5] & g[4]);
    
    assign s4_1 = ~p[4];
    wire cin1_to_5 = g[4] | p[4];
    assign s5_1 = p[5] ^ cin1_to_5;
    assign co_g2_1 = g[5] | (p[5] & cin1_to_5);
    
    assign sum[4] = cout_g1 ? s4_1 : s4_0;
    assign sum[5] = cout_g1 ? s5_1 : s5_0;
    wire cout_g2 = cout_g1 ? co_g2_1 : co_g2_0;
    
    // Group 3: bits 6-7 (dual-rail)
    wire s6_0, s7_0, co_g3_0;
    wire s6_1, s7_1, co_g3_1;
    
    assign s6_0 = p[6];
    assign s7_0 = p[7] ^ g[6];
    assign co_g3_0 = g[7] | (p[7] & g[6]);
    
    assign s6_1 = ~p[6];
    wire cin1_to_7 = g[6] | p[6];
    assign s7_1 = p[7] ^ cin1_to_7;
    assign co_g3_1 = g[7] | (p[7] & cin1_to_7);
    
    assign sum[6] = cout_g2 ? s6_1 : s6_0;
    assign sum[7] = cout_g2 ? s7_1 : s7_0;
    assign cout = cout_g2 ? co_g3_1 : co_g3_0;
    
endmodule