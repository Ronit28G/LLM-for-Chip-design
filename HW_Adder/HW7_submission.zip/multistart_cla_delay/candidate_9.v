module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);
    // Sparse tree with direct carry computation - minimize intermediate signals
    wire [7:0] p, g;
    
    assign p = a ^ b;
    assign g = a & b;
    
    // Build carries with shared sub-expressions
    wire pg0, pg10, pg210, pg3210;
    wire pg4, pg54, pg654, pg7654;
    
    // Lower half building blocks
    assign pg0 = p[0];
    assign pg10 = p[1] & p[0];
    assign pg210 = p[2] & p[1] & p[0];
    assign pg3210 = p[3] & p[2] & p[1] & p[0];
    
    // Upper half building blocks
    assign pg4 = p[4];
    assign pg54 = p[5] & p[4];
    assign pg654 = p[6] & p[5] & p[4];
    assign pg7654 = p[7] & p[6] & p[5] & p[4];
    
    // Carry computation using minimal gates
    wire c0, c1, c2, c3, c4, c5, c6;
    
    assign c0 = g[0];
    assign c1 = g[1] | (p[1] & g[0]);
    assign c2 = g[2] | (p[2] & g[1]) | (pg210 & g[0]);
    assign c3 = g[3] | (p[3] & g[2]) | (p[3] & p[2] & g[1]) | (pg3210 & g[0]);
    
    wire g3_or_terms = g[3] | (p[3] & g[2]) | (p[3] & p[2] & g[1]) | (pg3210 & g[0]);
    
    assign c4 = g[4] | (pg4 & g3_or_terms);
    assign c5 = g[5] | (p[5] & g[4]) | (pg54 & g3_or_terms);
    assign c6 = g[6] | (p[6] & g[5]) | (p[6] & p[5] & g[4]) | (pg654 & g3_or_terms);
    assign cout = g[7] | (p[7] & g[6]) | (p[7] & p[6] & g[5]) | (p[7] & p[6] & p[5] & g[4]) | (pg7654 & g3_or_terms);
    
    // Sum
    assign sum[0] = p[0];
    assign sum[1] = p[1] ^ c0;
    assign sum[2] = p[2] ^ c1;
    assign sum[3] = p[3] ^ c2;
    assign sum[4] = p[4] ^ c3;
    assign sum[5] = p[5] ^ c4;
    assign sum[6] = p[6] ^ c5;
    assign sum[7] = p[7] ^ c6;
    
endmodule