module adder8(input [7:0] a, b, output [7:0] sum, output cout);

  wire [7:0] g, p;
  wire [7:0] c;
  
  // Level 1: Generate and Propagate
  assign g[0] = a[0] & b[0];
  assign p[0] = a[0] ^ b[0];
  assign g[1] = a[1] & b[1];
  assign p[1] = a[1] ^ b[1];
  assign g[2] = a[2] & b[2];
  assign p[2] = a[2] ^ b[2];
  assign g[3] = a[3] & b[3];
  assign p[3] = a[3] ^ b[3];
  assign g[4] = a[4] & b[4];
  assign p[4] = a[4] ^ b[4];
  assign g[5] = a[5] & b[5];
  assign p[5] = a[5] ^ b[5];
  assign g[6] = a[6] & b[6];
  assign p[6] = a[6] ^ b[6];
  assign g[7] = a[7] & b[7];
  assign p[7] = a[7] ^ b[7];

  // Level 2-3: Brent-Kung prefix tree
  wire [7:1] g1, p1;
  assign g1[1] = g[1] | (p[1] & g[0]);
  assign p1[1] = p[1] & p[0];
  assign g1[2] = g[2] | (p[2] & g[1]);
  assign p1[2] = p[2] & p[1];
  assign g1[3] = g[3] | (p[3] & g[2]);
  assign p1[3] = p[3] & p[2];
  assign g1[4] = g[4] | (p[4] & g[3]);
  assign p1[4] = p[4] & p[3];
  assign g1[5] = g[5] | (p[5] & g[4]);
  assign p1[5] = p[5] & p[4];
  assign g1[6] = g[6] | (p[6] & g[5]);
  assign p1[6] = p[6] & p[5];
  assign g1[7] = g[7] | (p[7] & g[6]);
  assign p1[7] = p[7] & p[6];

  // Level 4-5: Second stage
  wire [7:2] g2, p2;
  assign g2[2] = g1[2] | (p1[2] & g[0]);
  assign p2[2] = p1[2] & p[0];
  assign g2[3] = g1[3] | (p1[3] & g1[1]);
  assign p2[3] = p1[3] & p1[1];
  assign g2[4] = g1[4] | (p1[4] & g1[2]);
  assign p2[4] = p1[4] & p1[2];
  assign g2[5] = g1[5] | (p1[5] & g1[3]);
  assign p2[5] = p1[5] & p1[3];
  assign g2[6] = g1[6] | (p1[6] & g1[4]);
  assign p2[6] = p1[6] & p1[4];
  assign g2[7] = g1[7] | (p1[7] & g1[5]);
  assign p2[7] = p1[7] & p1[5];

  // Level 6-7: Third stage
  wire [7:4] g3;
  assign g3[4] = g2[4] | (p2[4] & g[0]);
  assign g3[5] = g2[5] | (p2[5] & g1[1]);
  assign g3[6] = g2[6] | (p2[6] & g2[2]);
  assign g3[7] = g2[7] | (p2[7] & g2[3]);

  // Carry computation
  assign c[0] = g[0];
  assign c[1] = g1[1];
  assign c[2] = g2[2];
  assign c[3] = g2[3];
  assign c[4] = g3[4];
  assign c[5] = g3[5];
  assign c[6] = g3[6];
  assign c[7] = g3[7];

  // Sum computation
  assign sum[0] = p[0];
  assign sum[1] = p[1] ^ c[0];
  assign sum[2] = p[2] ^ c[1];
  assign sum[3] = p[3] ^ c[2];
  assign sum[4] = p[4] ^ c[3];
  assign sum[5] = p[5] ^ c[4];
  assign sum[6] = p[6] ^ c[5];
  assign sum[7] = p[7] ^ c[6];
  
  assign cout = c[7];

endmodule