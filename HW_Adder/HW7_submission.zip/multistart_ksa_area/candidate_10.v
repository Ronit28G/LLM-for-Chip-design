module adder8(input [7:0] a, b, output [7:0] sum, output cout);

  // Carry-skip adder with 4-bit blocks
  wire [7:0] p;
  
  // Block 0: bits 0-3
  assign p[0] = a[0] ^ b[0];
  assign p[1] = a[1] ^ b[1];
  assign p[2] = a[2] ^ b[2];
  assign p[3] = a[3] ^ b[3];
  
  wire g0 = a[0] & b[0];
  wire c1 = (a[1] & b[1]) | (p[1] & g0);
  wire c2 = (a[2] & b[2]) | (p[2] & a[1] & b[1]) | (p[2] & p[1] & g0);
  wire c3 = (a[3] & b[3]) | (p[3] & a[2] & b[2]) | (p[3] & p[2] & a[1] & b[1]) | (p[3] & p[2] & p[1] & g0);
  
  assign sum[0] = p[0];
  assign sum[1] = p[1] ^ g0;
  assign sum[2] = p[2] ^ c1;
  assign sum[3] = p[3] ^ c2;
  
  // Block 1: bits 4-7
  assign p[4] = a[4] ^ b[4];
  assign p[5] = a[5] ^ b[5];
  assign p[6] = a[6] ^ b[6];
  assign p[7] = a[7] ^ b[7];
  
  wire g4 = (a[4] & b[4]) | (p[4] & c3);
  wire c5 = (a[5] & b[5]) | (p[5] & a[4] & b[4]) | (p[5] & p[4] & c3);
  wire c6 = (a[6] & b[6]) | (p[6] & a[5] & b[5]) | (p[6] & p[5] & a[4] & b[4]) | (p[6] & p[5] & p[4] & c3);
  wire c7 = (a[7] & b[7]) | (p[7] & a[6] & b[6]) | (p[7] & p[6] & a[5] & b[5]) | (p[7] & p[6] & p[5] & a[4] & b[4]) | (p[7] & p[6] & p[5] & p[4] & c3);
  
  assign sum[4] = p[4] ^ c3;
  assign sum[5] = p[5] ^ g4;
  assign sum[6] = p[6] ^ c5;
  assign sum[7] = p[7] ^ c6;
  
  assign cout = c7;

endmodule