module adder8(input [7:0] a, b, output [7:0] sum, output cout);

  wire [7:0] p;
  wire [6:0] c;
  
  // Use XOR for propagate (shared with sum)
  assign p[0] = a[0] ^ b[0];
  assign p[1] = a[1] ^ b[1];
  assign p[2] = a[2] ^ b[2];
  assign p[3] = a[3] ^ b[3];
  assign p[4] = a[4] ^ b[4];
  assign p[5] = a[5] ^ b[5];
  assign p[6] = a[6] ^ b[6];
  assign p[7] = a[7] ^ b[7];
  
  // Carry chain using AOI logic to reduce cells
  // c[i] = g[i] | (p[i] & c[i-1]) = (a[i] & b[i]) | ((a[i] ^ b[i]) & c[i-1])
  assign c[0] = a[0] & b[0];
  assign c[1] = (a[1] & b[1]) | (p[1] & c[0]);
  assign c[2] = (a[2] & b[2]) | (p[2] & c[1]);
  assign c[3] = (a[3] & b[3]) | (p[3] & c[2]);
  assign c[4] = (a[4] & b[4]) | (p[4] & c[3]);
  assign c[5] = (a[5] & b[5]) | (p[5] & c[4]);
  assign c[6] = (a[6] & b[6]) | (p[6] & c[5]);
  
  // Sum uses pre-computed propagate
  assign sum[0] = p[0];
  assign sum[1] = p[1] ^ c[0];
  assign sum[2] = p[2] ^ c[1];
  assign sum[3] = p[3] ^ c[2];
  assign sum[4] = p[4] ^ c[3];
  assign sum[5] = p[5] ^ c[4];
  assign sum[6] = p[6] ^ c[5];
  assign sum[7] = p[7] ^ c[6];
  
  assign cout = (a[7] & b[7]) | (p[7] & c[6]);

endmodule