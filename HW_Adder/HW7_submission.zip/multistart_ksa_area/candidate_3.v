module adder8(input [7:0] a, b, output [7:0] sum, output cout);

  wire [7:0] p, g;
  
  // Generate and Propagate
  assign g[0] = a[0] & b[0];
  assign p[0] = a[0] ^ b[0];
  assign g[1] = a[1] & b[1];
  assign p[1] = a[1] ^ b[1];
  assign g[2] = a[2] & b[2];
  assign p[2] = a[2] ^ b[2];
  assign g[3] = a[3] & b[3];
  assign p[3] = a[3] ^ b[3];
  assign g[4] = a[4] & b[4];
  assign p[4] = a[4] ^ b[4];
  assign g[5] = a[5] & b[5];
  assign p[5] = a[5] ^ b[5];
  assign g[6] = a[6] & b[6];
  assign p[6] = a[6] ^ b[6];
  assign g[7] = a[7] & b[7];
  assign p[7] = a[7] ^ b[7];

  // Hybrid: 2-bit CLA blocks with ripple between blocks
  wire c1, c3, c5;
  wire g10, p10, g32, p32, g54, p54, g76, p76;
  
  // Block 0: bits 0-1
  assign g10 = g[1] | (p[1] & g[0]);
  assign p10 = p[1] & p[0];
  assign c1 = g[0];
  
  // Block 1: bits 2-3
  assign g32 = g[3] | (p[3] & g[2]);
  assign p32 = p[3] & p[2];
  assign c3 = g32 | (p32 & g10);
  
  // Block 2: bits 4-5
  assign g54 = g[5] | (p[5] & g[4]);
  assign p54 = p[5] & p[4];
  assign c5 = g54 | (p54 & c3);
  
  // Block 3: bits 6-7
  assign g76 = g[7] | (p[7] & g[6]);
  assign p76 = p[7] & p[6];
  
  // Sum computation
  assign sum[0] = p[0];
  assign sum[1] = p[1] ^ c1;
  assign sum[2] = p[2] ^ g10;
  assign sum[3] = p[3] ^ (g[2] | (p[2] & g10));
  assign sum[4] = p[4] ^ c3;
  assign sum[5] = p[5] ^ (g[4] | (p[4] & c3));
  assign sum[6] = p[6] ^ c5;
  assign sum[7] = p[7] ^ (g[6] | (p[6] & c5));
  
  assign cout = g76 | (p76 & c5);

endmodule