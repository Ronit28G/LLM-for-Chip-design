module adder8(input [7:0] a, b, output [7:0] sum, output cout);

  wire [7:0] p;
  wire [7:1] g1;
  wire [7:3] g2;
  
  // Level 1: Generate propagate inline
  assign p[0] = a[0] ^ b[0];
  assign p[1] = a[1] ^ b[1];
  assign p[2] = a[2] ^ b[2];
  assign p[3] = a[3] ^ b[3];
  assign p[4] = a[4] ^ b[4];
  assign p[5] = a[5] ^ b[5];
  assign p[6] = a[6] ^ b[6];
  assign p[7] = a[7] ^ b[7];
  
  // Level 2-3: Spanning tree carry (Han-Carlson style)
  assign g1[1] = (a[1] & b[1]) | (p[1] & a[0] & b[0]);
  assign g1[2] = (a[2] & b[2]) | (p[2] & a[1] & b[1]);
  assign g1[3] = (a[3] & b[3]) | (p[3] & a[2] & b[2]);
  assign g1[4] = (a[4] & b[4]) | (p[4] & a[3] & b[3]);
  assign g1[5] = (a[5] & b[5]) | (p[5] & a[4] & b[4]);
  assign g1[6] = (a[6] & b[6]) | (p[6] & a[5] & b[5]);
  assign g1[7] = (a[7] & b[7]) | (p[7] & a[6] & b[6]);
  
  // Level 4-5: Skip ahead by 2
  assign g2[3] = g1[3] | (p[3] & p[2] & g1[1]);
  assign g2[5] = g1[5] | (p[5] & p[4] & g1[3]);
  assign g2[7] = g1[7] | (p[7] & p[6] & g1[5]);
  
  // Sum with minimal carry
  assign sum[0] = p[0];
  assign sum[1] = p[1] ^ (a[0] & b[0]);
  assign sum[2] = p[2] ^ g1[1];
  assign sum[3] = p[3] ^ g1[2];
  assign sum[4] = p[4] ^ g2[3];
  assign sum[5] = p[5] ^ g1[4];
  assign sum[6] = p[6] ^ g2[5];
  assign sum[7] = p[7] ^ g1[6];
  
  assign cout = g2[7];

endmodule