module adder8(input [7:0] a, b, output [7:0] sum, output cout);

  // Carry-select adder: split into two 4-bit blocks
  wire [3:0] sum_low, sum_high0, sum_high1;
  wire cout_low, cout_high0, cout_high1;
  
  // Lower 4 bits with cin=0
  wire [3:0] p_low, g_low;
  assign p_low[0] = a[0] ^ b[0];
  assign g_low[0] = a[0] & b[0];
  assign p_low[1] = a[1] ^ b[1];
  assign g_low[1] = a[1] & b[1];
  assign p_low[2] = a[2] ^ b[2];
  assign g_low[2] = a[2] & b[2];
  assign p_low[3] = a[3] ^ b[3];
  assign g_low[3] = a[3] & b[3];
  
  wire c1, c2, c3;
  assign c1 = g_low[0];
  assign c2 = g_low[1] | (p_low[1] & g_low[0]);
  assign c3 = g_low[2] | (p_low[2] & g_low[1]) | (p_low[2] & p_low[1] & g_low[0]);
  assign cout_low = g_low[3] | (p_low[3] & g_low[2]) | (p_low[3] & p_low[2] & g_low[1]) | (p_low[3] & p_low[2] & p_low[1] & g_low[0]);
  
  assign sum_low[0] = p_low[0];
  assign sum_low[1] = p_low[1] ^ c1;
  assign sum_low[2] = p_low[2] ^ c2;
  assign sum_low[3] = p_low[3] ^ c3;
  
  // Upper 4 bits with cin=0 and cin=1
  wire [3:0] p_high;
  assign p_high[0] = a[4] ^ b[4];
  assign p_high[1] = a[5] ^ b[5];
  assign p_high[2] = a[6] ^ b[6];
  assign p_high[3] = a[7] ^ b[7];
  
  wire g4, g5, g6, g7;
  assign g4 = a[4] & b[4];
  assign g5 = a[5] & b[5];
  assign g6 = a[6] & b[6];
  assign g7 = a[7] & b[7];
  
  wire c5_0, c6_0, c7_0;
  assign c5_0 = g4;
  assign c6_0 = g5 | (p_high[1] & g4);
  assign c7_0 = g6 | (p_high[2] & g5) | (p_high[2] & p_high[1] & g4);
  
  wire c5_1, c6_1, c7_1;
  assign c5_1 = g4 | p_high[0];
  assign c6_1 = g5 | (p_high[1] & g4) | (p_high[1] & p_high[0]);
  assign c7_1 = g6 | (p_high[2] & g5) | (p_high[2] & p_high[1] & g4) | (p_high[2] & p_high[1] & p_high[0]);
  
  assign sum_high0[0] = p_high[0];
  assign sum_high0[1] = p_high[1] ^ c5_0;
  assign sum_high0[2] = p_high[2] ^ c6_0;
  assign sum_high0[3] = p_high[3] ^ c7_0;
  
  assign sum_high1[0] = ~p_high[0];
  assign sum_high1[1] = p_high[1] ^ c5_1;
  assign sum_high1[2] = p_high[2] ^ c6_1;
  assign sum_high1[3] = p_high[3] ^ c7_1;
  
  assign cout_high0 = g7 | (p_high[3] & g6) | (p_high[3] & p_high[2] & g5) | (p_high[3] & p_high[2] & p_high[1] & g4);
  assign cout_high1 = g7 | (p_high[3] & g6) | (p_high[3] & p_high[2] & g5) | (p_high[3] & p_high[2] & p_high[1] & g4) | (p_high[3] & p_high[2] & p_high[1] & p_high[0]);
  
  // Select based on cout_low
  assign sum[3:0] = sum_low;
  assign sum[7:4] = cout_low ? sum_high1 : sum_high0;
  assign cout = cout_low ? cout_high1 : cout_high0;

endmodule