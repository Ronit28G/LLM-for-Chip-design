module adder8(input [7:0] a, b, output [7:0] sum, output cout);

  wire [7:0] p;
  wire c0, c2, c4, c6;
  
  // Compute propagate for all bits
  assign p[0] = a[0] ^ b[0];
  assign p[1] = a[1] ^ b[1];
  assign p[2] = a[2] ^ b[2];
  assign p[3] = a[3] ^ b[3];
  assign p[4] = a[4] ^ b[4];
  assign p[5] = a[5] ^ b[5];
  assign p[6] = a[6] ^ b[6];
  assign p[7] = a[7] ^ b[7];
  
  // 2-bit block carries using sparse tree
  assign c0 = a[0] & b[0];
  
  wire g21, p21;
  assign g21 = (a[2] & b[2]) | (p[2] & a[1] & b[1]);
  assign p21 = p[2] & p[1];
  assign c2 = g21 | (p21 & c0);
  
  wire g43, p43;
  assign g43 = (a[4] & b[4]) | (p[4] & a[3] & b[3]);
  assign p43 = p[4] & p[3];
  assign c4 = g43 | (p43 & c2);
  
  wire g65, p65;
  assign g65 = (a[6] & b[6]) | (p[6] & a[5] & b[5]);
  assign p65 = p[6] & p[5];
  assign c6 = g65 | (p65 & c4);
  
  // Compute intermediate carries locally
  wire c1, c3, c5;
  assign c1 = (a[1] & b[1]) | (p[1] & c0);
  assign c3 = (a[3] & b[3]) | (p[3] & c2);
  assign c5 = (a[5] & b[5]) | (p[5] & c4);
  
  // Sum computation
  assign sum[0] = p[0];
  assign sum[1] = p[1] ^ c0;
  assign sum[2] = p[2] ^ c1;
  assign sum[3] = p[3] ^ c2;
  assign sum[4] = p[4] ^ c3;
  assign sum[5] = p[5] ^ c4;
  assign sum[6] = p[6] ^ c5;
  assign sum[7] = p[7] ^ c6;
  
  // Carry out
  assign cout = (a[7] & b[7]) | (p[7] & c6);

endmodule