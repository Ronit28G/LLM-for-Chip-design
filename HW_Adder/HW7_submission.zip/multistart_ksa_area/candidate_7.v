module adder8(input [7:0] a, b, output [7:0] sum, output cout);

  wire [7:0] p, g;
  
  // Stage 1: Basic G and P
  assign g[0] = a[0] & b[0];
  assign p[0] = a[0] | b[0];
  assign g[1] = a[1] & b[1];
  assign p[1] = a[1] | b[1];
  assign g[2] = a[2] & b[2];
  assign p[2] = a[2] | b[2];
  assign g[3] = a[3] & b[3];
  assign p[3] = a[3] | b[3];
  assign g[4] = a[4] & b[4];
  assign p[4] = a[4] | b[4];
  assign g[5] = a[5] & b[5];
  assign p[5] = a[5] | b[5];
  assign g[6] = a[6] & b[6];
  assign p[6] = a[6] | b[6];
  assign g[7] = a[7] & b[7];
  assign p[7] = a[7] | b[7];
  
  // Stage 2: Prefix computation
  wire [6:0] g_prefix;
  assign g_prefix[0] = g[1] | (p[1] & g[0]);
  assign g_prefix[1] = g[2] | (p[2] & g_prefix[0]);
  assign g_prefix[2] = g[3] | (p[3] & g_prefix[1]);
  assign g_prefix[3] = g[4] | (p[4] & g_prefix[2]);
  assign g_prefix[4] = g[5] | (p[5] & g_prefix[3]);
  assign g_prefix[5] = g[6] | (p[6] & g_prefix[4]);
  assign g_prefix[6] = g[7] | (p[7] & g_prefix[5]);
  
  // Sum using Manchester carry chain (inverted logic)
  assign sum[0] = a[0] ^ b[0];
  assign sum[1] = a[1] ^ b[1] ^ g[0];
  assign sum[2] = a[2] ^ b[2] ^ g_prefix[0];
  assign sum[3] = a[3] ^ b[3] ^ g_prefix[1];
  assign sum[4] = a[4] ^ b[4] ^ g_prefix[2];
  assign sum[5] = a[5] ^ b[5] ^ g_prefix[3];
  assign sum[6] = a[6] ^ b[6] ^ g_prefix[4];
  assign sum[7] = a[7] ^ b[7] ^ g_prefix[5];
  
  assign cout = g_prefix[6];

endmodule