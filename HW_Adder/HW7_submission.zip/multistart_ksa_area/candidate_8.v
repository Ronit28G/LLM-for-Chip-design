module adder8(input [7:0] a, b, output [7:0] sum, output cout);

  // Conditional sum adder with aggressive sharing
  wire [3:0] s0_lo, s1_lo;
  wire [3:0] s0_hi, s1_hi;
  wire c0_lo, c1_lo, c0_hi, c1_hi;
  
  // Lower 4-bit block, cin=0
  wire p0 = a[0] ^ b[0];
  wire g0 = a[0] & b[0];
  wire p1 = a[1] ^ b[1];
  wire g1 = a[1] & b[1];
  wire p2 = a[2] ^ b[2];
  wire g2 = a[2] & b[2];
  wire p3 = a[3] ^ b[3];
  wire g3 = a[3] & b[3];
  
  wire c1 = g0;
  wire c2 = g1 | (p1 & g0);
  wire c3 = g2 | (p2 & g1) | (p2 & p1 & g0);
  wire c4 = g3 | (p3 & g2) | (p3 & p2 & g1) | (p3 & p2 & p1 & g0);
  
  assign s0_lo[0] = p0;
  assign s0_lo[1] = p1 ^ c1;
  assign s0_lo[2] = p2 ^ c2;
  assign s0_lo[3] = p3 ^ c3;
  
  // Upper 4-bit block, both cin=0 and cin=1
  wire p4 = a[4] ^ b[4];
  wire p5 = a[5] ^ b[5];
  wire p6 = a[6] ^ b[6];
  wire p7 = a[7] ^ b[7];
  
  wire g4 = a[4] & b[4];
  wire g5 = a[5] & b[5];
  wire g6 = a[6] & b[6];
  wire g7 = a[7] & b[7];
  
  // For cin=0
  wire c5_0 = g4;
  wire c6_0 = g5 | (p5 & g4);
  wire c7_0 = g6 | (p6 & g5) | (p6 & p5 & g4);
  
  assign s0_hi[0] = p4;
  assign s0_hi[1] = p5 ^ c5_0;
  assign s0_hi[2] = p6 ^ c6_0;
  assign s0_hi[3] = p7 ^ c7_0;
  assign c0_hi = g7 | (p7 & g6) | (p7 & p6 & g5) | (p7 & p6 & p5 & g4);
  
  // For cin=1
  wire c5_1 = g4 | p4;
  wire c6_1 = g5 | (p5 & g4) | (p5 & p4);
  wire c7_1 = g6 | (p6 & g5) | (p6 & p5 & g4) | (p6 & p5 & p4);
  
  assign s1_hi[0] = ~p4;
  assign s1_hi[1] = p5 ^ c5_1;
  assign s1_hi[2] = p6 ^ c6_1;
  assign s1_hi[3] = p7 ^ c7_1;
  assign c1_hi = g7 | (p7 & g6) | (p7 & p6 & g5) | (p7 & p6 & p5 & g4) | (p7 & p6 & p5 & p4);
  
  // Final selection
  assign sum[3:0] = s0_lo;
  assign sum[4] = c4 ? s1_hi[0] : s0_hi[0];
  assign sum[5] = c4 ? s1_hi[1] : s0_hi[1];
  assign sum[6] = c4 ? s1_hi[2] : s0_hi[2];
  assign sum[7] = c4 ? s1_hi[3] : s0_hi[3];
  assign cout = c4 ? c1_hi : c0_hi;

endmodule