module adder8(input [7:0] a, b, output [7:0] sum, output cout);

  wire [7:0] p;
  wire [7:0] g;
  
  // Generate and propagate
  assign p = a ^ b;
  assign g[0] = a[0] & b[0];
  assign g[1] = a[1] & b[1];
  assign g[2] = a[2] & b[2];
  assign g[3] = a[3] & b[3];
  assign g[4] = a[4] & b[4];
  assign g[5] = a[5] & b[5];
  assign g[6] = a[6] & b[6];
  assign g[7] = a[7] & b[7];
  
  // Ladner-Fischer tree - reduced fanout version
  wire g1_1, g2_1, g3_2, g4_2, g5_4, g6_4, g7_4;
  wire p1_1, p2_1, p3_2, p4_2, p5_4, p6_4, p7_4;
  
  // Level 1: adjacent pairs
  assign g1_1 = g[1] | (p[1] & g[0]);
  assign p1_1 = p[1] & p[0];
  
  assign g2_1 = g[2] | (p[2] & g[1]);
  assign p2_1 = p[2] & p[1];
  
  assign g3_2 = g[3] | (p[3] & g[2]);
  assign p3_2 = p[3] & p[2];
  
  assign g4_2 = g[4] | (p[4] & g[3]);
  assign p4_2 = p[4] & p[3];
  
  assign g5_4 = g[5] | (p[5] & g[4]);
  assign p5_4 = p[5] & p[4];
  
  assign g6_4 = g[6] | (p[6] & g[5]);
  assign p6_4 = p[6] & p[5];
  
  assign g7_4 = g[7] | (p[7] & g[6]);
  assign p7_4 = p[7] & p[6];
  
  // Level 2: span of 4
  wire g3_0, g5_2, g7_4_final;
  assign g3_0 = g3_2 | (p3_2 & g1_1);
  assign g5_2 = g5_4 | (p5_4 & g3_2);
  assign g7_4_final = g7_4 | (p7_4 & g5_4);
  
  // Level 3: final carries
  wire g7_0;
  assign g7_0 = g7_4_final | (p7_4 & p5_4 & g3_0);
  
  // Carries for sum
  wire c0, c1, c2, c3, c4, c5, c6;
  assign c0 = g[0];
  assign c1 = g1_1;
  assign c2 = g2_1 | (p2_1 & g[0]);
  assign c3 = g3_0;
  assign c4 = g4_2 | (p4_2 & g2_1) | (p4_2 & p2_1 & g[0]);
  assign c5 = g5_2 | (p5_4 & p3_2 & g1_1);
  assign c6 = g6_4 | (p6_4 & g4_2) | (p6_4 & p4_2 & g2_1) | (p6_4 & p4_2 & p2_1 & g[0]);
  
  // Sum
  assign sum[0] = p[0];
  assign sum[1] = p[1] ^ c0;
  assign sum[2] = p[2] ^ c1;
  assign sum[3] = p[3] ^ c2;
  assign sum[4] = p[4] ^ c3;
  assign sum[5] = p[5] ^ c4;
  assign sum[6] = p[6] ^ c5;
  assign sum[7] = p[7] ^ c6;
  
  assign cout = g7_0;

endmodule