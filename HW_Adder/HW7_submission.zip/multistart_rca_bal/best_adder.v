module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);

wire [7:0] p, g;
wire [6:0] g1, p1;
wire [4:0] g2, p2;
wire [1:0] g3, p3;
wire g4;

// Level 0: Generate and Propagate
assign p[0] = a[0] ^ b[0];
assign g[0] = a[0] & b[0];
assign p[1] = a[1] ^ b[1];
assign g[1] = a[1] & b[1];
assign p[2] = a[2] ^ b[2];
assign g[2] = a[2] & b[2];
assign p[3] = a[3] ^ b[3];
assign g[3] = a[3] & b[3];
assign p[4] = a[4] ^ b[4];
assign g[4] = a[4] & b[4];
assign p[5] = a[5] ^ b[5];
assign g[5] = a[5] & b[5];
assign p[6] = a[6] ^ b[6];
assign g[6] = a[6] & b[6];
assign p[7] = a[7] ^ b[7];
assign g[7] = a[7] & b[7];

// Level 1: Span 2
assign g1[0] = g[1] | (p[1] & g[0]);
assign g1[2] = g[3] | (p[3] & g[2]);
assign g1[4] = g[5] | (p[5] & g[4]);
assign g1[6] = g[7] | (p[7] & g[6]);
assign p1[0] = p[1] & p[0];
assign p1[2] = p[3] & p[2];
assign p1[4] = p[5] & p[4];
assign p1[6] = p[7] & p[6];

// Level 2: Span 4
assign g2[0] = g1[2] | (p1[2] & g1[0]);
assign g2[4] = g1[6] | (p1[6] & g1[4]);
assign p2[0] = p1[2] & p1[0];
assign p2[4] = p1[6] & p1[4];

// Level 3: Span 8
assign g4 = g2[4] | (p2[4] & g2[0]);

// Reconstruct carries
wire c1, c2, c3, c4, c5, c6, c7;
assign c1 = g[0];
assign c2 = g1[0];
assign c3 = g[2] | (p[2] & g1[0]);
assign c4 = g2[0];
assign c5 = g[4] | (p[4] & g2[0]);
assign c6 = g1[4] | (p1[4] & g2[0]);
assign c7 = g[6] | (p[6] & g1[4]) | (p[6] & p1[4] & g2[0]);

// Sum
assign sum[0] = p[0];
assign sum[1] = p[1] ^ c1;
assign sum[2] = p[2] ^ c2;
assign sum[3] = p[3] ^ c3;
assign sum[4] = p[4] ^ c4;
assign sum[5] = p[5] ^ c5;
assign sum[6] = p[6] ^ c6;
assign sum[7] = p[7] ^ c7;
assign cout = g4;

endmodule