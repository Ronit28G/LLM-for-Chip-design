module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);

wire [3:0] c_low, c_high;
wire [3:0] sum_low_0, sum_high_0;
wire [3:0] sum_low_1, sum_high_1;
wire cout_low_0, cout_high_0;
wire cout_low_1, cout_high_1;
wire c4;

// Lower 4 bits with cin=0
assign sum_low_0[0] = a[0] ^ b[0];
assign c_low[0] = a[0] & b[0];

assign sum_low_0[1] = a[1] ^ b[1] ^ c_low[0];
assign c_low[1] = (a[1] & b[1]) | ((a[1] ^ b[1]) & c_low[0]);

assign sum_low_0[2] = a[2] ^ b[2] ^ c_low[1];
assign c_low[2] = (a[2] & b[2]) | ((a[2] ^ b[2]) & c_low[1]);

assign sum_low_0[3] = a[3] ^ b[3] ^ c_low[2];
assign cout_low_0 = (a[3] & b[3]) | ((a[3] ^ b[3]) & c_low[2]);

// Upper 4 bits with cin=0
assign sum_high_0[0] = a[4] ^ b[4];
assign c_high[0] = a[4] & b[4];

assign sum_high_0[1] = a[5] ^ b[5] ^ c_high[0];
assign c_high[1] = (a[5] & b[5]) | ((a[5] ^ b[5]) & c_high[0]);

assign sum_high_0[2] = a[6] ^ b[6] ^ c_high[1];
assign c_high[2] = (a[6] & b[6]) | ((a[6] ^ b[6]) & c_high[1]);

assign sum_high_0[3] = a[7] ^ b[7] ^ c_high[2];
assign cout_high_0 = (a[7] & b[7]) | ((a[7] ^ b[7]) & c_high[2]);

// Upper 4 bits with cin=1
assign sum_high_1[0] = ~sum_high_0[0];
assign sum_high_1[1] = sum_high_0[1] ^ c_high[0];
assign sum_high_1[2] = sum_high_0[2] ^ c_high[1];
assign sum_high_1[3] = sum_high_0[3] ^ c_high[2];
assign cout_high_1 = cout_high_0 | c_high[2];

// Select based on carry from lower 4 bits
assign sum[3:0] = sum_low_0;
assign sum[7:4] = cout_low_0 ? sum_high_1 : sum_high_0;
assign cout = cout_low_0 ? cout_high_1 : cout_high_0;

endmodule