module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);

wire [7:0] p;
wire [7:1] c;

// Propagate (shared for sum and carry)
assign p = a ^ b;

// Optimized carry chain using AOI logic
assign c[1] = (a[0] & b[0]);
assign c[2] = (a[1] & b[1]) | (p[1] & a[0] & b[0]);
assign c[3] = (a[2] & b[2]) | (p[2] & a[1] & b[1]) | (p[2] & p[1] & a[0] & b[0]);
assign c[4] = (a[3] & b[3]) | (p[3] & a[2] & b[2]) | (p[3] & p[2] & a[1] & b[1]) | (p[3] & p[2] & p[1] & a[0] & b[0]);
assign c[5] = (a[4] & b[4]) | (p[4] & a[3] & b[3]) | (p[4] & p[3] & a[2] & b[2]) | (p[4] & p[3] & p[2] & a[1] & b[1]) | (p[4] & p[3] & p[2] & p[1] & a[0] & b[0]);
assign c[6] = (a[5] & b[5]) | (p[5] & a[4] & b[4]) | (p[5] & p[4] & a[3] & b[3]) | (p[5] & p[4] & p[3] & a[2] & b[2]) | (p[5] & p[4] & p[3] & p[2] & a[1] & b[1]) | (p[5] & p[4] & p[3] & p[2] & p[1] & a[0] & b[0]);
assign c[7] = (a[6] & b[6]) | (p[6] & a[5] & b[5]) | (p[6] & p[5] & a[4] & b[4]) | (p[6] & p[5] & p[4] & a[3] & b[3]) | (p[6] & p[5] & p[4] & p[3] & a[2] & b[2]) | (p[6] & p[5] & p[4] & p[3] & p[2] & a[1] & b[1]) | (p[6] & p[5] & p[4] & p[3] & p[2] & p[1] & a[0] & b[0]);
assign cout = (a[7] & b[7]) | (p[7] & a[6] & b[6]) | (p[7] & p[6] & a[5] & b[5]) | (p[7] & p[6] & p[5] & a[4] & b[4]) | (p[7] & p[6] & p[5] & p[4] & a[3] & b[3]) | (p[7] & p[6] & p[5] & p[4] & p[3] & a[2] & b[2]) | (p[7] & p[6] & p[5] & p[4] & p[3] & p[2] & a[1] & b[1]) | (p[7] & p[6] & p[5] & p[4] & p[3] & p[2] & p[1] & a[0] & b[0]);

// Sum
assign sum[0] = p[0];
assign sum[7:1] = p[7:1] ^ c[7:1];

endmodule