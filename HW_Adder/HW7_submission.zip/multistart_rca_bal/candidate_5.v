module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);

wire [7:0] p, g;
wire [3:0] gg, gp;
wire [1:0] ggg, ggp;
wire c4;

// Stage 0: bit-level generate and propagate
assign g = a & b;
assign p = a ^ b;

// Stage 1: 2-bit groups
wire g10, g32, g54, g76;
wire p10, p32, p54, p76;

assign g10 = g[1] | (p[1] & g[0]);
assign p10 = p[1] & p[0];
assign g32 = g[3] | (p[3] & g[2]);
assign p32 = p[3] & p[2];
assign g54 = g[5] | (p[5] & g[4]);
assign p54 = p[5] & p[4];
assign g76 = g[7] | (p[7] & g[6]);
assign p76 = p[7] & p[6];

// Stage 2: 4-bit groups
wire g30, g74;
wire p30, p74;

assign g30 = g32 | (p32 & g10);
assign p30 = p32 & p10;
assign g74 = g76 | (p76 & g54);
assign p74 = p76 & p54;

// Stage 3: 8-bit group
assign cout = g74 | (p74 & g30);

// Carry calculation
wire c1, c2, c3, c5, c6, c7;

assign c1 = g[0];
assign c2 = g10;
assign c3 = g[2] | (p[2] & g10);
assign c4 = g30;
assign c5 = g[4] | (p[4] & g30);
assign c6 = g54 | (p54 & g30);
assign c7 = g[6] | (p[6] & g54) | (p[6] & p54 & g30);

// Sum calculation
assign sum[0] = p[0];
assign sum[1] = p[1] ^ c1;
assign sum[2] = p[2] ^ c2;
assign sum[3] = p[3] ^ c3;
assign sum[4] = p[4] ^ c4;
assign sum[5] = p[5] ^ c5;
assign sum[6] = p[6] ^ c6;
assign sum[7] = p[7] ^ c7;

endmodule