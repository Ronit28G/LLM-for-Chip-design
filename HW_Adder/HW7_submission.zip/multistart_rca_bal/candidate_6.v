module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);

wire [2:0] c;
wire [7:0] s0, s1;
wire [2:0] co0, co1;

// First 2-bit block (bits 0-1)
assign s0[0] = a[0] ^ b[0];
assign s0[1] = a[1] ^ b[1] ^ (a[0] & b[0]);
assign c[0] = (a[1] & b[1]) | ((a[1] ^ b[1]) & (a[0] & b[0]));

// Second 2-bit block (bits 2-3)
assign s0[2] = a[2] ^ b[2];
assign co0[0] = a[2] & b[2];
assign s1[2] = ~s0[2];
assign co1[0] = a[2] | b[2];

assign s0[3] = a[3] ^ b[3] ^ co0[0];
assign co0[1] = (a[3] & b[3]) | ((a[3] ^ b[3]) & co0[0]);
assign s1[3] = a[3] ^ b[3] ^ co1[0];
assign co1[1] = (a[3] & b[3]) | ((a[3] ^ b[3]) & co1[0]);

assign sum[1:0] = s0[1:0];
assign sum[3:2] = c[0] ? s1[3:2] : s0[3:2];
assign c[1] = c[0] ? co1[1] : co0[1];

// Third 2-bit block (bits 4-5)
assign s0[4] = a[4] ^ b[4];
assign co0[2] = a[4] & b[4];
assign s1[4] = ~s0[4];
assign co1[2] = a[4] | b[4];

wire c4_0, c4_1;
assign s0[5] = a[5] ^ b[5] ^ co0[2];
assign c4_0 = (a[5] & b[5]) | ((a[5] ^ b[5]) & co0[2]);
assign s1[5] = a[5] ^ b[5] ^ co1[2];
assign c4_1 = (a[5] & b[5]) | ((a[5] ^ b[5]) & co1[2]);

assign sum[5:4] = c[1] ? s1[5:4] : s0[5:4];
assign c[2] = c[1] ? c4_1 : c4_0;

// Fourth 2-bit block (bits 6-7)
wire s0_6, s1_6, co0_3, co1_3;
assign s0_6 = a[6] ^ b[6];
assign co0_3 = a[6] & b[6];
assign s1_6 = ~s0_6;
assign co1_3 = a[6] | b[6];

wire s0_7, s1_7, c6_0, c6_1;
assign s0_7 = a[7] ^ b[7] ^ co0_3;
assign c6_0 = (a[7] & b[7]) | ((a[7] ^ b[7]) & co0_3);
assign s1_7 = a[7] ^ b[7] ^ co1_3;
assign c6_1 = (a[7] & b[7]) | ((a[7] ^ b[7]) & co1_3);

assign sum[6] = c[2] ? s1_6 : s0_6;
assign sum[7] = c[2] ? s1_7 : s0_7;
assign cout = c[2] ? c6_1 : c6_0;

endmodule