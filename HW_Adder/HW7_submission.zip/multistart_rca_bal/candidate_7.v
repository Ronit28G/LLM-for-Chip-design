module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);

wire [7:0] p;
wire c1, c2, c3, c4, c5, c6, c7;

assign p = a ^ b;

// Incremental carry using minimal logic
assign c1 = a[0] & b[0];

assign c2 = (a[1] & b[1]) | (p[1] & c1);

assign c3 = (a[2] & b[2]) | (p[2] & a[1] & b[1]) | (p[2] & p[1] & c1);

assign c4 = (a[3] & b[3]) | (p[3] & a[2] & b[2]) | 
            (p[3] & p[2] & a[1] & b[1]) | (p[3] & p[2] & p[1] & c1);

assign c5 = (a[4] & b[4]) | (p[4] & a[3] & b[3]) | 
            (p[4] & p[3] & a[2] & b[2]) | (p[4] & p[3] & p[2] & a[1] & b[1]) | 
            (p[4] & p[3] & p[2] & p[1] & c1);

assign c6 = (a[5] & b[5]) | (p[5] & a[4] & b[4]) | 
            (p[5] & p[4] & a[3] & b[3]) | (p[5] & p[4] & p[3] & a[2] & b[2]) | 
            (p[5] & p[4] & p[3] & p[2] & a[1] & b[1]) | 
            (p[5] & p[4] & p[3] & p[2] & p[1] & c1);

assign c7 = (a[6] & b[6]) | (p[6] & a[5] & b[5]) | 
            (p[6] & p[5] & a[4] & b[4]) | (p[6] & p[5] & p[4] & a[3] & b[3]) | 
            (p[6] & p[5] & p[4] & p[3] & a[2] & b[2]) | 
            (p[6] & p[5] & p[4] & p[3] & p[2] & a[1] & b[1]) | 
            (p[6] & p[5] & p[4] & p[3] & p[2] & p[1] & c1);

assign cout = (a[7] & b[7]) | (p[7] & a[6] & b[6]) | 
              (p[7] & p[6] & a[5] & b[5]) | (p[7] & p[6] & p[5] & a[4] & b[4]) | 
              (p[7] & p[6] & p[5] & p[4] & a[3] & b[3]) | 
              (p[7] & p[6] & p[5] & p[4] & p[3] & a[2] & b[2]) | 
              (p[7] & p[6] & p[5] & p[4] & p[3] & p[2] & a[1] & b[1]) | 
              (p[7] & p[6] & p[5] & p[4] & p[3] & p[2] & p[1] & c1);

assign sum[0] = p[0];
assign sum[1] = p[1] ^ c1;
assign sum[2] = p[2] ^ c2;
assign sum[3] = p[3] ^ c3;
assign sum[4] = p[4] ^ c4;
assign sum[5] = p[5] ^ c5;
assign sum[6] = p[6] ^ c6;
assign sum[7] = p[7] ^ c7;

endmodule