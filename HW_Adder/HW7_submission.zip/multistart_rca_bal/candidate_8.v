module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);

wire [7:0] xor_ab;
wire [6:0] c;

// Single XOR computation for propagate
assign xor_ab = a ^ b;

// Ripple with shared XOR - minimize total gates
assign sum[0] = xor_ab[0];

wire and01, and12, and23, and34, and45, and56, and67;

assign and01 = a[0] & b[0];
assign c[0] = and01;
assign sum[1] = xor_ab[1] ^ and01;

assign and12 = (a[1] & b[1]) | (xor_ab[1] & and01);
assign c[1] = and12;
assign sum[2] = xor_ab[2] ^ and12;

assign and23 = (a[2] & b[2]) | (xor_ab[2] & and12);
assign c[2] = and23;
assign sum[3] = xor_ab[3] ^ and23;

assign and34 = (a[3] & b[3]) | (xor_ab[3] & and23);
assign c[3] = and34;
assign sum[4] = xor_ab[4] ^ and34;

assign and45 = (a[4] & b[4]) | (xor_ab[4] & and34);
assign c[4] = and45;
assign sum[5] = xor_ab[5] ^ and45;

assign and56 = (a[5] & b[5]) | (xor_ab[5] & and45);
assign c[5] = and56;
assign sum[6] = xor_ab[6] ^ and56;

assign and67 = (a[6] & b[6]) | (xor_ab[6] & and56);
assign c[6] = and67;
assign sum[7] = xor_ab[7] ^ and67;

assign cout = (a[7] & b[7]) | (xor_ab[7] & and67);

endmodule