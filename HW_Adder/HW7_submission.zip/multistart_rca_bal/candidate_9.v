module adder8(
    input [7:0] a,
    input [7:0] b,
    output [7:0] sum,
    output cout
);

wire [7:0] p, g;
wire g1_10, g1_32, g1_54, g1_76;
wire p1_10, p1_32, p1_54, p1_76;
wire g2_30, g2_74;
wire p2_30;
wire g3_70;

// Level 0
assign p = a ^ b;
assign g = a & b;

// Level 1: pairs
assign g1_10 = g[1] | (p[1] & g[0]);
assign p1_10 = p[1] & p[0];
assign g1_32 = g[3] | (p[3] & g[2]);
assign p1_32 = p[3] & p[2];
assign g1_54 = g[5] | (p[5] & g[4]);
assign p1_54 = p[5] & p[4];
assign g1_76 = g[7] | (p[7] & g[6]);
assign p1_76 = p[7] & p[6];

// Level 2: quads (only compute what we need)
assign g2_30 = g1_32 | (p1_32 & g1_10);
assign p2_30 = p1_32 & p1_10;
assign g2_74 = g1_76 | (p1_76 & g1_54);

// Level 3: final carry
assign g3_70 = g2_74 | (p1_76 & p1_54 & g2_30);
assign cout = g3_70;

// Carries with minimal recomputation
wire c1, c2, c3, c4, c5, c6, c7;
assign c1 = g[0];
assign c2 = g1_10;
assign c3 = g[2] | (p[2] & g1_10);
assign c4 = g2_30;
assign c5 = g[4] | (p[4] & g2_30);
assign c6 = g1_54 | (p1_54 & g2_30);
assign c7 = g[6] | (p[6] & g1_54) | (p[6] & p1_54 & g2_30);

// Sums
assign sum[0] = p[0];
assign sum[1] = p[1] ^ c1;
assign sum[2] = p[2] ^ c2;
assign sum[3] = p[3] ^ c3;
assign sum[4] = p[4] ^ c4;
assign sum[5] = p[5] ^ c5;
assign sum[6] = p[6] ^ c6;
assign sum[7] = p[7] ^ c7;

endmodule