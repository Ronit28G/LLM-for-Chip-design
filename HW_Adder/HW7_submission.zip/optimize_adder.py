import subprocess, re, os, json, anthropic

def parse_stats(log):
    ppa = {}
    m = re.search(r"Chip area for module.*?:\s+([\d.]+)", log)
    ppa["area_um2"] = float(m.group(1)) if m else None
    m = re.search(r"Number of cells:\s+(\d+)", log)
    ppa["cell_count"] = int(m.group(1)) if m else None
    m = re.search(r"lev\s*=\s*(\d+)", log)
    ppa["logic_levels"] = int(m.group(1)) if m else None
    return ppa

def synthesize(verilog_file, top_module):
    script = f"""read_verilog {verilog_file}
hierarchy -check -top {top_module}
flatten
proc; opt; fsm; opt; memory; opt
techmap; opt
abc -liberty nangate45.lib -script "+strash;ifraig;scorr;dc2;dretime;retime;strash;&get -n;&dch -f;&nf;&put;print_stats"
clean
stat -liberty nangate45.lib
"""
    with open("temp_synth.ys", "w") as f:
        f.write(script)
    result = subprocess.run(
        ["yosys", "-s", "temp_synth.ys"],
        capture_output=True, text=True
    )
    log = result.stdout + result.stderr
    return parse_stats(log), log

def build_system_prompt(delay_target):
    return f"""You are an expert digital circuit designer specializing in arithmetic circuits.
Your goal is to generate synthesizable Verilog for an 8-bit adder that minimizes
cell count while meeting a delay target of at most {delay_target} logic levels.
STRICT RULES:
- Respond with ONLY valid Verilog code, no markdown, no explanation
- Top-level module MUST be named adder8
- Ports MUST be: input [7:0] a, b, output [7:0] sum, output cout
- Do NOT reuse the ripple carry adder - try a fundamentally different architecture
- Consider: Carry Lookahead, Brent-Kung, Kogge-Stone, Carry Select, Han-Carlson
- Each iteration you MUST propose a DIFFERENT architecture from the previous one"""

def build_feedback_prompt(iteration, ppa, best_ppa, delay_target):
    return f"""Iteration {iteration} synthesis results:
- Cell count: {ppa["cell_count"]}
- Logic levels: {ppa["logic_levels"]}
- Area: {ppa["area_um2"]} um2
Best so far: {best_ppa["cell_count"]} cells, {best_ppa["logic_levels"]} levels.
Delay target: <= {delay_target} logic levels.
YOUR PREVIOUS DESIGN DID NOT IMPROVE. Try a completely different architecture.
Provide ONLY Verilog with top-level module named adder8."""

def llm_generate(history, system_prompt):
    client = anthropic.Anthropic()
    response = client.messages.create(
        model="claude-sonnet-4-5",
        max_tokens=4000,
        system=system_prompt,
        messages=history
    )
    return response.content[0].text.strip()

def run_optimization_loop(baseline_verilog, mode, delay_target, max_iter=10, out_dir="."):
    os.makedirs(out_dir, exist_ok=True)
    history = []
    best_ppa = {"cell_count": 1e9, "logic_levels": 1e9, "area_um2": 1e9}
    best_code = baseline_verilog
    results = []
    system_prompt = build_system_prompt(delay_target)

    history.append({
        "role": "user",
        "content": f"Here is an 8-bit adder baseline:\n{baseline_verilog}\nStart from this design."
    })

    for i in range(1, max_iter + 1):
        print(f"\n=== Mode {mode} - Iteration {i} ===")
        verilog = llm_generate(history, system_prompt)
        verilog = verilog.replace("```verilog", "").replace("```", "").strip()

        fname = f"{out_dir}/candidate_{i}.v"
        with open(fname, "w") as f:
            f.write(verilog)

        try:
            ppa, _ = synthesize(fname, "adder8")
            if ppa["cell_count"] is None:
                raise ValueError("Null metrics")
        except Exception as e:
            print(f"  Synthesis failed: {e}")
            history.append({"role": "assistant", "content": verilog})
            history.append({"role": "user", "content": "Synthesis failed. Fix errors. Module must be named adder8."})
            continue

        print(f"  Cells: {ppa["cell_count"]}  Levels: {ppa["logic_levels"]}  Area: {ppa["area_um2"]} um2")
        results.append({"iteration": i, "ppa": ppa, "file": fname})

        if (ppa["logic_levels"] is not None and
            ppa["logic_levels"] <= delay_target and
            ppa["cell_count"] < best_ppa["cell_count"]):
            best_ppa = ppa
            best_code = verilog
            print("  *** New best! ***")

        history.append({"role": "assistant", "content": verilog})
        history.append({"role": "user", "content": build_feedback_prompt(i, ppa, best_ppa, delay_target)})

    with open(f"{out_dir}/best_adder.v", "w") as f:
        f.write(best_code)
    with open(f"{out_dir}/optimization_log.json", "w") as f:
        json.dump({"mode": mode, "delay_target": delay_target,
                   "best_ppa": best_ppa, "iterations": results}, f, indent=2)

    print(f"\n=== Mode {mode} Complete ===")
    print(f"Best PPA: {best_ppa}")
    return best_code, best_ppa, results

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline", default="RCA8_golden.v")
    parser.add_argument("--mode", default="C")
    parser.add_argument("--delay-target", type=int, default=10)
    parser.add_argument("--max-iter", type=int, default=10)
    parser.add_argument("--out", default="output")
    args = parser.parse_args()

    with open(args.baseline) as f:
        baseline = f.read()

    run_optimization_loop(baseline, args.mode, args.delay_target, args.max_iter, args.out)
