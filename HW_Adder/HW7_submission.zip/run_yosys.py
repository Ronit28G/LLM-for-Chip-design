import subprocess, re, os, json

def parse_stats(log):
    ppa = {}
    m = re.search(r"Chip area for module.*?:\s+([\d.]+)", log)
    ppa["area_um2"] = float(m.group(1)) if m else None
    m = re.search(r"Number of cells:\s+(\d+)", log)
    ppa["cell_count"] = int(m.group(1)) if m else None
    m = re.search(r"lev\s*=\s*(\d+)", log)
    ppa["logic_levels"] = int(m.group(1)) if m else None
    return ppa

def synthesize(verilog_file, top_module):
    script = f"""read_verilog {verilog_file}
hierarchy -check -top {top_module}
flatten
proc; opt; fsm; opt; memory; opt
techmap; opt
abc -liberty nangate45.lib -script "+strash;ifraig;scorr;dc2;dretime;retime;strash;&get -n;&dch -f;&nf;&put;print_stats"
clean
stat -liberty nangate45.lib
"""
    with open("temp_synth.ys", "w") as f:
        f.write(script)
    result = subprocess.run(
        ["yosys", "-s", "temp_synth.ys"],
        capture_output=True, text=True
    )
    log = result.stdout + result.stderr
    return parse_stats(log), log

if __name__ == "__main__":
    import sys
    ppa, _ = synthesize(sys.argv[1], sys.argv[2])
    print(json.dumps(ppa, indent=2))
