module tb_internal_cla8;
  reg [7:0] a, b;
  wire [7:0] sum;
  wire cout;

  carry_lookahead_adder uut (.sum(sum), .cout(cout), .a(a), .b(b));

  initial begin
    $display("=== CLA8 Internal Signal Verification ===");

    // Test 1: simple addition
    a = 8'b00000001; b = 8'b00000001; #10;
    $display("a=%b b=%b sum=%b cout=%b", a, b, sum, cout);
    $display("  g=%b p=%b", uut.g, uut.p);
    $display("  c=%b", uut.c);

    // Test 2: full carry propagation
    a = 8'b11111111; b = 8'b00000001; #10;
    $display("a=%b b=%b sum=%b cout=%b", a, b, sum, cout);
    $display("  g=%b p=%b", uut.g, uut.p);
    $display("  c=%b", uut.c);

    // Test 3: lower nibble carry
    a = 8'b00001111; b = 8'b00000001; #10;
    $display("a=%b b=%b sum=%b cout=%b", a, b, sum, cout);
    $display("  g=%b p=%b", uut.g, uut.p);
    $display("  c=%b", uut.c);

    // Test 4: all zeros
    a = 8'b00000000; b = 8'b00000000; #10;
    $display("a=%b b=%b sum=%b cout=%b", a, b, sum, cout);
    $display("  g=%b p=%b", uut.g, uut.p);
    $display("  c=%b", uut.c);

    $finish;
  end
endmodule