module tb_internal;
  reg [7:0] a, b;
  wire [7:0] sum;
  wire cout;

  eight_bit_ripple_carry_adder uut (.sum(sum), .cout(cout), .a(a), .b(b));

  initial begin
    $display("=== RCA8 Internal Signal Verification ===");
    $display("%-10s %-10s %-10s %-6s %-50s", "a", "b", "sum", "cout", "carries carry[0]-carry[6]");

    // Test 1: simple addition, no carry propagation
    a = 8'b00000001; b = 8'b00000001; #10;
    $display("%-10b %-10b %-10b %-6b carry[0]=%b carry[1]=%b carry[2]=%b carry[3]=%b carry[4]=%b carry[5]=%b carry[6]=%b",
              a, b, sum, cout, uut.carry[0], uut.carry[1], uut.carry[2], uut.carry[3], uut.carry[4], uut.carry[5], uut.carry[6]);

    // Test 2: all ones + 1, full carry propagation
    a = 8'b11111111; b = 8'b00000001; #10;
    $display("%-10b %-10b %-10b %-6b carry[0]=%b carry[1]=%b carry[2]=%b carry[3]=%b carry[4]=%b carry[5]=%b carry[6]=%b",
              a, b, sum, cout, uut.carry[0], uut.carry[1], uut.carry[2], uut.carry[3], uut.carry[4], uut.carry[5], uut.carry[6]);

    // Test 3: lower nibble carry only
    a = 8'b00001111; b = 8'b00000001; #10;
    $display("%-10b %-10b %-10b %-6b carry[0]=%b carry[1]=%b carry[2]=%b carry[3]=%b carry[4]=%b carry[5]=%b carry[6]=%b",
              a, b, sum, cout, uut.carry[0], uut.carry[1], uut.carry[2], uut.carry[3], uut.carry[4], uut.carry[5], uut.carry[6]);

    // Test 4: all zeros, no carry
    a = 8'b00000000; b = 8'b00000000; #10;
    $display("%-10b %-10b %-10b %-6b carry[0]=%b carry[1]=%b carry[2]=%b carry[3]=%b carry[4]=%b carry[5]=%b carry[6]=%b",
              a, b, sum, cout, uut.carry[0], uut.carry[1], uut.carry[2], uut.carry[3], uut.carry[4], uut.carry[5], uut.carry[6]);

    $finish;
  end
endmodule